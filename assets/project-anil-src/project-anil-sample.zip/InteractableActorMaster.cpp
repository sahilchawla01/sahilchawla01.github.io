// Fill out your copyright notice in the Description page of Project Settings.


#include "InteractableActorMaster.h"
#include "Components/WidgetComponent.h"
#include "../MainCharacter.h"
#include "../ActorComponents/InteractionComponents/InteractableTextComponent.h"
#include "../ActorComponents/InteractionComponents/InteractableInspectComponent.h"
#include "Kismet/GameplayStatics.h"
#include "../Events/HorrorEventMaster.h"
#include "../MCPlayerController.h"

DEFINE_LOG_CATEGORY(LogInteractableActor);

// Sets default values
AInteractableActorMaster::AInteractableActorMaster()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(Root);

	ActorMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ActorMesh"));
	ActorMesh->SetupAttachment(Root);

	//TODO: Change magic text to a variable that comes from a blueprint dropdown
	//Set default collision channel to InteractableActor
	ActorMesh->SetCollisionProfileName(TEXT("InteractableActor"));
	ActorMesh->SetGenerateOverlapEvents(true);

	//Initialise Interaction UI Location
	InteractUILocation = CreateDefaultSubobject<USceneComponent>(TEXT("InteractUILocation"));
	InteractUILocation->SetupAttachment(Root);

	//Initialise interactable potential UI
	InteractPotentialUI = CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractablePotentialUI"));
	InteractPotentialUI->SetWidgetSpace(EWidgetSpace::Screen);
	InteractPotentialUI->SetupAttachment(InteractUILocation);

	//Initialise interactable key UI
	InteractKeyUI = CreateDefaultSubobject<UWidgetComponent>(TEXT("InteractableKeyUI"));
	InteractKeyUI->SetWidgetSpace(EWidgetSpace::Screen);
	InteractKeyUI->SetupAttachment(InteractUILocation);

}

// Called when the game starts or when spawned
void AInteractableActorMaster::BeginPlay()
{
	Super::BeginPlay();


	//Initially hide it
	InteractKeyUI->SetVisibility(false);
	InteractPotentialUI->SetVisibility(false);
	
	//Get mc player controller
	StorePlayerControllerRef();

	if (MCPlayerController == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Could not get main character player controller in actor: %s"), *GetActorNameOrLabel());
		return;
	}

	//Set widget classes for potential and interact key UIs
	if (MCPlayerController->InteractKeyUIClass) InteractKeyUI->SetWidgetClass(MCPlayerController->InteractKeyUIClass);
	if (MCPlayerController->InteractPotentialUIClass) InteractPotentialUI->SetWidgetClass(MCPlayerController->InteractPotentialUIClass);

	//Check for existence of text components, rotate components, animation components 
	//Check for text component and store
	InteractableTextComponentRef = FindComponentByClass<UInteractableTextComponent>();

	if (InteractableTextComponentRef)
	{
		//Store player controller 
		InteractableTextComponentRef->SetPlayerControllerRef(MCPlayerController);
	} 

	//Check for inspect component and store
	InteractableInspectComponentRef = FindComponentByClass<UInteractableInspectComponent>();
	if (InteractableInspectComponentRef)
	{
		//Store player controller in component
		InteractableInspectComponentRef->SetPlayerControllerRef(MCPlayerController);
	}


}

// Called every frame
void AInteractableActorMaster::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AInteractableActorMaster::Interact_Implementation()
{
	//Incase player controller is null, store it
	StorePlayerControllerRef();
	//Store main character ref in case already standing in potential zone of actor and potential function wasn't fired
	StoreMainCharacterRef();

	check(MainCharRef);
	//Store this actor's reference in main character, in case it has not been interacted with through Raycasting (for example: interacting with bench on beginplay) 
	MainCharRef->SetInteractableActor(Cast<AActor>(this));

	if (!bCanBeInteractedWith)
	{
		//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
		return;
	}
	//UE_LOG(LogTemp, Warning, TEXT("Object interacted with, Default Interaction"));
	SetIsInteracting(true);

	if (InteractableInspectComponentRef)
	{
		InteractableInspectComponentRef->SetRequiredVariables();
		InteractableInspectComponentRef->StartInspecting();
	}

	if (InteractableTextComponentRef)
	{InteractableTextComponentRef->SetInteractionText();
		InteractableTextComponentRef->ShowInteractionText();
		InteractableTextComponentRef->PlayFadeInInteractionTextAnimation();
	}

	//Spawn horror event
	if (HorrorEventClass)
	{
		FTransform SpawnTransform;
		SpawnTransform.SetLocation(GetActorLocation());
		SpawnTransform.SetRotation(GetActorRotation().Quaternion());

		const FActorSpawnParameters SpawnParams;

		//This means that the event was spawned and has not yet been destroyed, if that is the case, stop & destroy earlier event and continue
		if (HorrorEventToPlay)
		{
			HorrorEventToPlay->StopEvents();
		}

		HorrorEventToPlay = GetWorld()->SpawnActor<AHorrorEventMaster>(HorrorEventClass, SpawnTransform, SpawnParams);

		if (!HorrorEventToPlay) UE_LOG(LogInteractableActor, Warning, TEXT("HorrorEvent actor couldn't be spawned"));
	}
	else
		UE_LOG(LogInteractableActor, Warning, TEXT("HorrorEventClass was not assigned in actor: %s"), *(GetActorNameOrLabel()));

	//Hide the buttons when interacted with
	HideInteractButton_Implementation();
	HideInteractPotential_Implementation();

	UE_LOG(LogInteractableActor, Display, TEXT("Interacted on a master level with actor: %s"), *(GetActorNameOrLabel()));
}

void AInteractableActorMaster::EndInteraction_Implementation()
{
	if (!bCanBeInteractedWith)
	{
		//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
		return;
	}

	if (!bIsInteracting) return;

	SetIsInteracting(false);

	//Default behaviour, on end interaction, hide interaction text
	if (InteractableTextComponentRef)
	{
		//TODO: Set this upto call it after the animation ends
		//InteractableTextComponentRef->HideInteractionText();
		InteractableTextComponentRef->PlayFadeOutInteractionTextAnimation();
	}

	if (InteractableInspectComponentRef)
	{
		InteractableInspectComponentRef->StopInspecting();
	}

	//UE_LOG(LogTemp, Warning, TEXT("Object interaction over, Default Interaction"));

	//Show interact potential 
	ShowInteractPotential_Implementation();
	//Hide interact button
	HideInteractButton_Implementation();

	UE_LOG(LogInteractableActor, Display, TEXT("Ended Interaction on a master level with actor: %s"), *(GetActorNameOrLabel()));
}

void AInteractableActorMaster::ShowInteractPotential_Implementation()
{
	//Incase player controller is null, store it
	StorePlayerControllerRef();
	//Since this is the first function fired when interacting with such an actor, store MainCharacter reference
	StoreMainCharacterRef();

	if (!bCanBeInteractedWith)
	{
		//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
		return;
	}

	if (bIsInteracting) return;

	if (!bCanShowInteractionUI) return;

	bIsShowingInteractPotential = true;

	InteractPotentialUI->SetVisibility(true);

	UE_LOG(LogInteractableActor, Display, TEXT("Show object interaction potential, Default Interaction on actor: %s"), *(GetActorNameOrLabel()));
}

void AInteractableActorMaster::HideInteractPotential_Implementation()
{
	/*if (!bCanBeInteractedWith)
	{*/
		//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
	/*	return;
	}*/

	bIsShowingInteractPotential = false;
	InteractPotentialUI->SetVisibility(false);
	//UE_LOG(LogTemp, Warning, TEXT("Hide object interaction potential, Default Interaction"));
}

void AInteractableActorMaster::ShowInteractButton_Implementation()
{
	if (!bCanBeInteractedWith)
	{
		//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
		return;
	}

	if (bIsInteracting) 
	{
		//UE_LOG(LogTemp, Warning, TEXT("Returned, already interacting"));
		return;
	}

	if (!bCanShowInteractionUI) return;

	bIsShowingInteractKey = true;

	InteractKeyUI->SetVisibility(true);

	//UE_LOG(LogInteractableActor, Warning, TEXT("Show object interaction button, Default Interaction"));
}

void AInteractableActorMaster::HideInteractButton_Implementation()
{
	//If trying to hide even when it cannot be interacted with, let it
	//if (!bCanBeInteractedWith)
	//{
	//	//UE_LOG(LogTemp, Error, TEXT("This actor cannot be interacted with"));
	//	return;
	//}

	bIsShowingInteractKey = false;

	InteractKeyUI->SetVisibility(false);

	//UE_LOG(LogTemp, Warning, TEXT("Hide object interaction button, Default Interaction"));
}


UStaticMeshComponent* AInteractableActorMaster::GetActorMesh()
{
	return ActorMesh;
}

USceneComponent* AInteractableActorMaster::GetRootComponent()
{
	return Root;
}

bool AInteractableActorMaster::GetIsActorBeingInteractedWith() const
{
	UE_LOG(LogInteractableActor, Display, TEXT("InteractableActor: Is actor being interacted with: %u"), bIsInteracting);
	return bIsInteracting;  
}

void AInteractableActorMaster::SetIsInteracting(bool isInteracting)
{
	bIsInteracting = isInteracting;

	if (MCPlayerController)
	{
		AMainCharacter* MC = MCPlayerController->GetMainCharacter();

		if(MC) MC->SetIsCharacterInteracting(isInteracting);
	}

	UE_LOG(LogInteractableActor, Display, TEXT("InteractableActor: Actor being interacted flag was set to: %u"), bIsInteracting);
}

void AInteractableActorMaster::StorePlayerControllerRef()
{
	if(MCPlayerController == nullptr) MCPlayerController = Cast<AMCPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
}

void AInteractableActorMaster::StoreMainCharacterRef()
{
	if(MCPlayerController && MainCharRef == nullptr) MainCharRef = MCPlayerController->GetMainCharacter();
}

void AInteractableActorMaster::SetInteractability(bool bCanInteract)
{
	bCanBeInteractedWith = bCanInteract;

	//UE_LOG(LogTemp, Display, TEXT("Interactibility on actor: %s was set to %i"), *(GetActorNameOrLabel()), bCanInteract);
}

void AInteractableActorMaster::SetCanShowInteractionUI(bool bCanShow)
{
	bCanShowInteractionUI = bCanShow;
}

void AInteractableActorMaster::ShowInteractionUI(bool bShow)
{
	check(InteractKeyUI);
	check(InteractPotentialUI);

	//UE_LOG(LogInteractableActor, Display, TEXT("ShowInteractionUI?: %i"), bShow);

	InteractKeyUI->SetVisibility(bShow);
	InteractPotentialUI->SetVisibility(bShow);
}




