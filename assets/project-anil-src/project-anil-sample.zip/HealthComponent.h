// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HealthComponent.generated.h"


UENUM(BlueprintType)
enum EHealthState: uint8
{
	Dead,
	Critical,
	Injured,
	Healthy,
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnHealthDamageSignature, float, NewHealth, EHealthState, PreviousHealthState, EHealthState, NewHealthState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnHealthHealSignature, float, NewHealth, EHealthState, PreviousHealthState, EHealthState, NewHealthState);

class AHorrorEventMaster;

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class PROJECTANIL_API UHealthComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UHealthComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY() FOnHealthDamageSignature OnHealthDamageDelegate;
	UPROPERTY() FOnHealthHealSignature OnHealthHealDelegate;

	bool GetIsCharacterDead() { return bIsDead; }
	EHealthState GetCurrentHealthState() { return CurrentHealthState; }


	UFUNCTION(BlueprintCallable) void DamageTaken(AActor* DamagedActor, float Damage, const UDamageType* DamageType, class AController* Instigator, AActor* DamageCauser);
	UFUNCTION(BlueprintCallable) void Heal(float HealAmount);
	UFUNCTION(BlueprintCallable) const bool CheckIfDamageKillsPlayer(const float Damage);

private:
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"), Category = "Health Settings") float MaxHealth = 100.f;
	//The minimum health required to be in a healthy state
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"), Category = "Health Settings") float HealthyThreshold = 70.f;
	//The minimum health required to be in an injured state
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"), Category = "Health Settings") float InjuredThreshold = 40.f;
	//The enum that decides the current state of the character
	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"), Category = "Health Settings") TEnumAsByte<EHealthState> CurrentHealthState = EHealthState::Healthy;

	UPROPERTY(EditDefaultsOnly) TSubclassOf<AHorrorEventMaster> DamagedHorrorEventClass = nullptr;
	UPROPERTY() AHorrorEventMaster* DamagedHorrorEventToPlay = nullptr;
	UPROPERTY(EditDefaultsOnly) TSubclassOf<AHorrorEventMaster> HealHorrorEventClass = nullptr;
	UPROPERTY() AHorrorEventMaster* HealHorrorEventToPlay = nullptr;

	float CurrentHealth = 100.f;
	bool bIsDead = false;

	void EvaluateAndSetHealthState(const UDamageType* DamageType = nullptr);

	//Horor events that must be spawned when taking damage (for example: playing a sound)
	void SpawnOnDamageHorrorEvent();
	void SpawnOnHealHorrorEvent();




		
};
