// Fill out your copyright notice in the Description page of Project Settings.


#include "CharacterCinematicsHandler.h"
#include "Kismet/GameplayStatics.h"
#include "LevelSequenceActor.h"
#include "LevelSequence.h"
#include "LevelSequencePlayer.h"
#include "../../MainCharacter.h"
#include "../../MCPlayerController.h"
#include "../../Actors/InteractableActorMaster.h"
#include "../../ActorComponents/MainCharacterComponents/CharacterCinematicsHandler.h"
#include "DefaultLevelSequenceInstanceData.h"
#include "Camera/CameraActor.h"

DEFINE_LOG_CATEGORY(LogCharacterCinematicHandler);

// Sets default values for this component's properties
UCharacterCinematicsHandler::UCharacterCinematicsHandler()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UCharacterCinematicsHandler::BeginPlay()
{
	Super::BeginPlay();

	// Get the level sequence actor in the level
	LevelSeqActorRef = Cast<ALevelSequenceActor>(UGameplayStatics::GetActorOfClass(this, ALevelSequenceActor::StaticClass()));

	if (LevelSeqActorRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't find level sequence actor in level on CharacterCinematicsHandler"));
		return;
	}

	//Enable override instance data on level sequence actor
	LevelSeqActorRef->bOverrideInstanceData = true;

	//Store main character ref
	MCRef = Cast<AMainCharacter>(GetOwner());
	if (MCRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't cast to MainCharacter on CharacterCinematicsHandler"));
		return;
	}

	//Store player controller referece
	//PCRef = Cast<AMCPlayerController>(MCRef->GetController());
	PCRef = Cast<AMCPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0));
	if (PCRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't cast to AMCPlayerController on CharacterCinematicsHandler"));
		return;
	}
	//Store the level sequence player to bind the on finished function
	ULevelSequencePlayer* LevelSeqPlayerRef = LevelSeqActorRef->GetSequencePlayer();

	if (LevelSeqPlayerRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't find LevelSeqPlayerRef in level on CharacterCinematicsHandler"));
		return;
	}

	//Bind the functions onPlay and OnFinish
	LevelSeqPlayerRef->OnPlay.AddDynamic(this, &UCharacterCinematicsHandler::LevelSequenceStartedPlaying);
	LevelSeqPlayerRef->OnFinished.AddDynamic(this, &UCharacterCinematicsHandler::LevelSequenceFinishedPlaying);

	//Store the level sequence referenced in the actor
	LevelSequenceRef = LevelSeqActorRef->GetSequence();

	if (LevelSequenceRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't find LevelSequenceRef in level on CharacterCinematicsHandler"));
		return;
	}

}


// Called every frame
void UCharacterCinematicsHandler::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UCharacterCinematicsHandler::SetAndPlayLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, bool bCinematicAffectsInteractibility, bool IsAutomaticLevelSeqFinishAllowed, FVector TransformOriginActorLocation, FRotator TransformOriginNewRotation)
{
	SetLevelSequence(NewLevelSequence, LevelSeqType, bCinematicAffectsInteractibility, TransformOriginActorLocation, TransformOriginNewRotation);
	PlaySelectedLevelSequence();

	bIsAutomaticLevelSeqFinishedAllowed = IsAutomaticLevelSeqFinishAllowed;
}

void UCharacterCinematicsHandler::SetAndPlayLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, ACameraActor* CinematicCamera, bool bCinematicAffectsInteractibility, bool IsAutomaticLevelSeqFinishAllowed, FVector TransformOriginActorLocation, FRotator TransformOriginNewRotation)
{
	SetLevelSequence(NewLevelSequence, LevelSeqType, bCinematicAffectsInteractibility, TransformOriginActorLocation, TransformOriginNewRotation);
	CinematicCameraActorRef = CinematicCamera;
	PlaySelectedLevelSequence();

	bIsAutomaticLevelSeqFinishedAllowed = IsAutomaticLevelSeqFinishAllowed;
}

void UCharacterCinematicsHandler::SetLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, bool bCinematicAffectsInteractibility, FVector TransformOriginActorLocation, FRotator TransformOriginNewRotation)
{
	//If not safe to play seq, return
	if (!CheckIfSafeToPlaySequence()) return;
	//If new level seq is non-existent, return
	if (NewLevelSequence == nullptr) return;

	//Set level sequence
	LevelSeqActorRef->SetSequence(NewLevelSequence);
	//Set level seq ref
	LevelSequenceRef = NewLevelSequence;
	//Set level sequence type
	CinematicAnimationType = LevelSeqType;

	//Set whether this cinematic should enable/disable "interactibility" of Actor
	bCurrentCinematicAffectsInteractibility = bCinematicAffectsInteractibility;

	//Set location of TransformOriginActor so cinematic works dynamically, relative to the location
	SetupTransformOriginActor(TransformOriginActorLocation, TransformOriginNewRotation);
}

void UCharacterCinematicsHandler::SetupTransformOriginActor(const FVector& TransformOriginActorLocation, const FRotator& TransformOriginActorNewRotation)
{
	//First, enable overrideinstancedata so that we can change TransformOriginActor as required according to cinematic
	LevelSeqActorRef->bOverrideInstanceData = true;

	//Next set transform origin actor to Level Sequence Actor, such that level sequence plays relative to this actor
	Cast<UDefaultLevelSequenceInstanceData>(LevelSeqActorRef->DefaultInstanceData)->TransformOriginActor = LevelSeqActorRef;

	//Set the location of TransformOriginActor i.e Level Sequence Actor to the requested location
	LevelSeqActorRef->SetActorLocation(TransformOriginActorLocation);
	//Set rotation of LevelSeqActor to requestion rotation
	LevelSeqActorRef->SetActorRotation(TransformOriginActorNewRotation);
}

void UCharacterCinematicsHandler::PlaySelectedLevelSequence()
{
	//If not safe to play seq, return
	if (!CheckIfSafeToPlaySequence()) return;

	ULevelSequencePlayer* LevelSeqPlayerRef = LevelSeqActorRef->GetSequencePlayer();

	if (!LevelSeqPlayerRef) return;


	if (MCRef)
	{
		//Set interactibility of that actor to false
		CinematicActorInteractedWith = Cast<AInteractableActorMaster>(MCRef->GetInteractableActor());

		if (CinematicActorInteractedWith == nullptr)
		{
			UE_LOG(LogTemp, Error, TEXT("When PlayingSelectedLevelSequence on CharacterCinematicsHandler, InteractableActor was null"));
		} 
		else
			if(bCurrentCinematicAffectsInteractibility) CinematicActorInteractedWith->SetInteractability(false);

		//Remove player control
		MCRef->SetEnableInput(false);
	}
	

	//If camera actor passed, blend to that camera
	if (CinematicCameraActorRef && PCRef)
	{

		//TODO: Blend camera to sequence camera
		PCRef->SetViewTargetWithBlend(CinematicCameraActorRef);

	}

	//Play the sequence
	LevelSeqPlayerRef->Play();
	
}

bool UCharacterCinematicsHandler::CheckIfSafeToPlaySequence()
{
	if (LevelSeqActorRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't find level sequence actor in level on CharacterCinematicsHandler"));
		return false;
	}

	if (MCRef == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Couldn't find MainCharacterRef on CharacterCinematicsHandler"));
		return false;
	}

	return true;

}

void UCharacterCinematicsHandler::StopPlayingLevelSequence()
{
	//If not safe to play seq, return
	if (!CheckIfSafeToPlaySequence()) return;

	ULevelSequencePlayer* LevelSeqPlayerRef = LevelSeqActorRef->GetSequencePlayer();

	if (!LevelSeqPlayerRef) return;

	//Stop the sequence
	LevelSeqPlayerRef->Stop();

	ExitLevelSequenceInteraction();
	
}

void UCharacterCinematicsHandler::ExitLevelSequenceInteraction()
{
	//Blend camera back to player camera 
	if (CinematicCameraActorRef)
	{
		//TODO: Blend camera back to player camera
		PCRef->SetViewTargetWithBlend(MCRef);
		CinematicCameraActorRef = nullptr;
	}

	//End character's interaction by calling StopInteract
	if (MCRef)
	{
		MCRef->StopInteracting(CinematicActorInteractedWith);
		//Return player control
		MCRef->SetEnableInput(true);

		//PATCH: If interactibility of actor is not affected, manually tell character that interaction has stopped
		if (!bCurrentCinematicAffectsInteractibility) MCRef->SetIsCharacterInteracting(false);

		//Clear the cinematic actor after exiting the level seq interaction
		CinematicActorInteractedWith = nullptr;
	}
}

void UCharacterCinematicsHandler::LevelSequenceStartedPlaying()
{
	//Broadcast that cinematic has started
	OnCharacterCinematicStartedDelegate.Broadcast();

	UE_LOG(LogCharacterCinematicHandler, Display, TEXT("CharacterCinematicStartedDelegate Broadcasted!"));
}

void UCharacterCinematicsHandler::LevelSequenceFinishedPlaying()
{
#if WITH_EDITOR
	UE_LOG(LogCharacterCinematicHandler, Warning, TEXT("LevelSequenceFinishedPlaying, but is automatic exit allowed: %i , CharacterCinematicComplete Broadcasted."));
#endif
	//Broadcast that cinematic was complete
	OnCharacterCinematicCompleteDelegate.Broadcast();

	if (!bIsAutomaticLevelSeqFinishedAllowed) return;


	//UE_LOG(LogTemp, Warning, TEXT("Level Sequence finished playing!!"));

	if(bCurrentCinematicAffectsInteractibility && CinematicActorInteractedWith) CinematicActorInteractedWith->SetInteractability(true);

	ExitLevelSequenceInteraction();
}

AActor* UCharacterCinematicsHandler::GetActorFromTagInLevelSeq(const FName& Tag, bool& OutSuccess)
{
	if (LevelSequenceRef == nullptr)
	{
		UE_LOG(LogCharacterCinematicHandler, Warning, TEXT("When getting an actor from tag %s, level sequence was found to be null"), *(Tag.ToString()));
		OutSuccess = false;
		return nullptr;
	}
	//Get Guid of specified tag bound to an actor
	const FGuid LevelSeqGuid = LevelSequenceRef->FindBindingByTag(Tag).GetGuid();

	//Declare actor array
	TArray<UObject*, TInlineAllocator<1>> OutObjects;

	//Get bound objects
	LevelSequenceRef->LocateBoundObjects(LevelSeqGuid, GetWorld(), OutObjects);

	if (OutObjects.Num() > 0)
	{
		OutSuccess = true;
		UE_LOG(LogCharacterCinematicHandler, Display, TEXT("Found an actor in level seq!"));
		return Cast<AActor>(OutObjects[0]);
	} 

	UE_LOG(LogCharacterCinematicHandler, Warning, TEXT("Couldn't locate any bound objects with Guid: %s"), *(LevelSeqGuid.ToString()));
	OutSuccess = false;
	return nullptr;
}

ULevelSequencePlayer* UCharacterCinematicsHandler::GetLevelSequencePlayer()
{
	if(LevelSeqActorRef) return LevelSeqActorRef->GetSequencePlayer();

	return nullptr;
}

