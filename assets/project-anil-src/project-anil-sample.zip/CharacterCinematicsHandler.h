// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "../../Animation/AnimInstances/MainCharacter/MainCharacterAnimInstance.h"
#include "CharacterCinematicsHandler.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnCharacterCinematicStarted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnCharacterCinematicComplete);
DECLARE_LOG_CATEGORY_EXTERN(LogCharacterCinematicHandler, Log, All);

class ULevelSequence;
class ULevelSequencePlayer;


/**
* This class handles the first person cinematics for the character such as entering/exiting the vent, waking up from table, etc.
* 
* IMPORTANT: TransformOriginActor is important as it decides relative to what actor, is the cinematic playing. In this class we assign the LevelSeqActor as the TransformOriginActor. We then assign the location and rotation of the LevelSeqActor with the inputted values of InteractableCinematicActor. 
*/
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class PROJECTANIL_API UCharacterCinematicsHandler : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UCharacterCinematicsHandler();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	//Sets and plays the reference to the new level sequence provided
	void SetAndPlayLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, bool bCinematicAffectsInteractibility = true, bool IsAutomaticLevelSeqFinishAllowed = true, FVector TransformOriginActorLocation = FVector::Zero(), FRotator TransformOriginNewRotation = FRotator::ZeroRotator);
	//Sets and plays the reference to the new level sequence provided, along with blending to the cinematic camera
	void SetAndPlayLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, ACameraActor* CinematicCamera, bool bCinematicAffectsInteractibility = true, bool IsAutomaticLevelSeqFinishAllowed = true, FVector TransformOriginActorLocation = FVector::Zero(), FRotator TransformOriginNewRotation = FRotator::ZeroRotator);
	//Only sets the reference to the new level sequence
	void SetLevelSequence(ULevelSequence* NewLevelSequence, ECharacterCineLevelSequence LevelSeqType, bool bCinematicAffectsInteractibility = true, FVector TransformOriginActorLocation = FVector::Zero(), FRotator TransformOriginNewRotation = FRotator::ZeroRotator);
	//Sets TransformOriginActor as LevelSeqActor and sets the location of the same actor to the given location
	void SetupTransformOriginActor(const FVector& TransformOriginActorLocation, const FRotator& TransformOriginActorNewRotation);
	//Plays the currently set level sequence 
	void PlaySelectedLevelSequence();
	//Checks if all reference variables are not-null required to play sequence
	bool CheckIfSafeToPlaySequence();
	//Stop the currently playing level sequence
	void StopPlayingLevelSequence();
	//Exit the level sequence 
	void ExitLevelSequenceInteraction();
	//Level sequence started playing
	UFUNCTION() void LevelSequenceStartedPlaying();
	//The level sequence has finished
	UFUNCTION() void LevelSequenceFinishedPlaying();

	//This is used to get the actor from the specified tag
	AActor* GetActorFromTagInLevelSeq(const FName& Tag, bool& OutSuccess);

	UPROPERTY() FOnCharacterCinematicStarted OnCharacterCinematicStartedDelegate;
	UPROPERTY() FOnCharacterCinematicComplete OnCharacterCinematicCompleteDelegate;

	//Getter
	ULevelSequencePlayer* GetLevelSequencePlayer();

private:

	UPROPERTY() class ALevelSequenceActor* LevelSeqActorRef;
	UPROPERTY() ULevelSequence* LevelSequenceRef;
	UPROPERTY() ACameraActor* CinematicCameraActorRef;
	UPROPERTY() class AMainCharacter* MCRef;
	UPROPERTY() class AInteractableActorMaster* CinematicActorInteractedWith;
	UPROPERTY() class AMCPlayerController* PCRef;

	ECharacterCineLevelSequence CinematicAnimationType;

	//Used to determine whether the LevelSequenceFinishedPlaying dynamic should be called when a level sequence finishes automatically
	bool bIsAutomaticLevelSeqFinishedAllowed = true;
	//Should current cinematic being played affect the "Interactability" of the Actor
	bool bCurrentCinematicAffectsInteractibility = true;


};
