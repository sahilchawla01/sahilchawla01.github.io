// Fill out your copyright notice in the Description page of Project Settings.

//TODO: 1) Interpolate camera anims

#include "MainCharacter.h"
#include "InputMappingContext.h"
#include "EnhancedInputSubsystems.h"
#include "EnhancedInputComponent.h"
#include "InputAction.h"
#include "MCPlayerController.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Interfaces/InteractionMasterInterface.h"
#include "Actors/InteractableActorMaster.h"
#include "Actors/InteractableDoor.h"
#include "Actors/ProjectorPuzzle/ProjectorPuzzleActor.h"
#include "Actors/Minigames/PadlockCuttingMinigameActor.h"
#include "ActorComponents/InteractionComponents/InteractableInspectComponent.h"
#include "ActorComponents/MainCharacterComponents/MainCharacterGrabber.h"
#include "ActorComponents/MainCharacterComponents/CharacterCinematicsHandler.h"
#include "ActorComponents/MainCharacterComponents/CharacterCameraShakeComponent.h"
#include "ActorComponents/MainCharacterComponents/HealthComponent.h"
#include "ActorComponents/PlayerControllerComponents/UIManager.h"
#include "Animation/AnimInstances/MainCharacter/MainCharacterAnimInstance.h"
#include "Blueprint/UserWidget.h"
#include "PrototypeGameMode.h"
#include "MCCameraManager.h"
#include "CineCameraActor.h"

DEFINE_LOG_CATEGORY(LogMainCharacter);

// Sets default values
AMainCharacter::AMainCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMainCharacter::BeginPlay()
{
	Super::BeginPlay();

    StoreComponentReferences();

    OriginalCameraLoc = FVector(GetCameraComponent()->GetComponentLocation());
    OriginalCameraRelativeLoc = FVector(GetCameraComponent()->GetRelativeLocation());


    //Store original camera rotation min maxvalues
    if (CameraManagerRef != nullptr)
    {
        //Store yaw values
        OrigMinYaw = CameraManagerRef->ViewYawMin;
        OrigMaxYaw = CameraManagerRef->ViewYawMax;

        //Store pitch values
        OrigMinPitch = CameraManagerRef->ViewPitchMin;
        OrigMaxPitch = CameraManagerRef->ViewPitchMax;
    }

    //Get capsule height before 
    float TotalStandingCapsuleHeight = GetCapsuleComponent()->GetUnscaledCapsuleHalfHeight();
    //UE_LOG(LogTemp, Warning, TEXT("TotalStandingCapsuleHeight: %f"), TotalStandingCapsuleHeight);

    //By default it is 38cm
    float TotalCrouchedCapsuleHeight = 38.f;
    if (CharMovementCompRef)
    {
        TotalCrouchedCapsuleHeight = CharMovementCompRef->GetCrouchedHalfHeight();
        //UE_LOG(LogTemp, Warning, TEXT("TotalCrouchedCapsuleHeight: %f"), TotalCrouchedCapsuleHeight);
    }

    CameraCrouchOffset = TotalStandingCapsuleHeight - TotalCrouchedCapsuleHeight;

    CrouchedCameraOrigRelativeLoc = OriginalCameraRelativeLoc;
    //As capsule height decreases, we must offset the position
    CrouchedCameraOrigRelativeLoc.Z += CameraCrouchOffset;

    //Store the scene component location of the crawl camera position
    CrawlCameraRelativeLoc = FindComponentByTag<USceneComponent>("Crawl")->GetRelativeLocation();
    //As Crouch() is called, capsule height decreases, thus original CameraPos moves, thus we must provide this offset
    CrawlCameraRelativeLoc.Z += CameraCrouchOffset;
    //UE_LOG(LogTemp, Display, TEXT("Crawl Camera Relative Position:%s"), *(CrawlCameraRelativeLoc.ToString()));

    ResetCharacterState();

    //Subscribe to the sensitivity change delegate to set sensitivity when delegate is broadcasted
    if (UIManagerRef) UIManagerRef->OnSensitivityChangeDelegate.AddUniqueDynamic(this, &AMainCharacter::SetMouseSensitivityScale);

}

// Called every frame
void AMainCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
    
    //If already interacting, don't check for other interactables
    //if (!GetIsInteracting()) /*CastRayAndCheckInteractable();*/
    CastRayAndCheckInteractable();

    //UE_LOG(LogTemp, Display, TEXT("Current Control Rotation: %s"), *(GetControlRotation().ToString()));
    //UE_LOG(LogTemp, Display, TEXT("Current Mesh Location: %s"), *(GetMesh()->GetComponentLocation().ToString()));
}

// Called to bind functionality to input
void AMainCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

    SetInputContextToDefault();

    // Get the EnhancedInputComponent
    UEnhancedInputComponent* PEI = Cast<UEnhancedInputComponent>(PlayerInputComponent);
    // Bind the actions
    if (InputMove != nullptr)
    {
        PEI->BindAction(InputMove, ETriggerEvent::Triggered, this, &AMainCharacter::Move);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputMove doesn't exist"));
    }
    if (InputLook != nullptr)
    {
        PEI->BindAction(InputLook, ETriggerEvent::Triggered, this, &AMainCharacter::Look);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputLook doesn't exist"));
    }
    if (InputJogActivate != nullptr)
    {
        PEI->BindAction(InputJogActivate, ETriggerEvent::Triggered, this, &AMainCharacter::ActivateJog);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputJogActivate doesn't exist"));
    }
    if (InputJogDeactivate != nullptr)
    {
        PEI->BindAction(InputJogDeactivate, ETriggerEvent::Triggered, this, &AMainCharacter::DeactivateJog);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputJogDeactivate doesn't exist"));
    }
    if (InputInteract != nullptr)
    {
        PEI->BindAction(InputInteract, ETriggerEvent::Triggered, this, &AMainCharacter::InteractWithActor);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputInteract doesn't exist"));
    }
    if (InputGrab != nullptr)
    {
        PEI->BindAction(InputGrab, ETriggerEvent::Triggered, this, &AMainCharacter::StartedGrabbing);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputGrab doesn't exist"));
    }
    if (InputRelease != nullptr)
    {
        PEI->BindAction(InputRelease, ETriggerEvent::Triggered, this, &AMainCharacter::StoppedGrabbing);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputRelease doesn't exist"));
    }
    if (InputThrowObject != nullptr)
    {
        PEI->BindAction(InputThrowObject, ETriggerEvent::Triggered, this, &AMainCharacter::ThrowObject);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputThrowObject doesn't exist"));
    }
    if (InputCrawlActivate != nullptr)
    {
        PEI->BindAction(InputCrawlActivate, ETriggerEvent::Triggered, this, &AMainCharacter::CrawlInputReceived);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputCrouchActivate doesn't exist"));
    }
    if (InputCrawlDeactivate != nullptr)
    {
        PEI->BindAction(InputCrawlDeactivate, ETriggerEvent::Triggered, this, &AMainCharacter::UncrawlInputReceived);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputCrouchDeactivate doesn't exist"));
    }
    if (InputInspectActivate != nullptr)
    {
        PEI->BindAction(InputInspectActivate, ETriggerEvent::Triggered, this, &AMainCharacter::ActivateInspectHold);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputInspectActivate doesn't exist"));
    }
    if (InputInspectDeactivate != nullptr)
    {
        PEI->BindAction(InputInspectDeactivate, ETriggerEvent::Triggered, this, &AMainCharacter::DeactivateInspectHold);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputInspectDeactivate doesn't exist"));
    }
    if (InputZoom != nullptr)
    {
        PEI->BindAction(InputZoom, ETriggerEvent::Triggered, this, &AMainCharacter::ZoomInspectableActor);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputZoom doesn't exist"));
    }
    if (InputProjectorHoverLeftRight != nullptr)
    {
        PEI->BindAction(InputProjectorHoverLeftRight, ETriggerEvent::Triggered, this, &AMainCharacter::ProjectorPuzzleHover);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputProjectorHoverLeftRight doesn't exist"));
    }
    if (InputProjectorSelectOrReplace != nullptr)
    {
        PEI->BindAction(InputProjectorSelectOrReplace, ETriggerEvent::Triggered, this, &AMainCharacter::ProjectorPuzzleSelectOrReplace);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputProjectorSelectOrReplace doesn't exist"));
    }
    if (InputProjectorLeavePuzzle != nullptr)
    {
        PEI->BindAction(InputProjectorLeavePuzzle, ETriggerEvent::Triggered, this, &AMainCharacter::ProjectorPuzzleLeave);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputProjectorLeavePuzzle doesn't exist"));
    }
    if (InputProjectorPlay != nullptr)
    {
        PEI->BindAction(InputProjectorPlay, ETriggerEvent::Triggered, this, &AMainCharacter::ProjectorPuzzlePlay);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputProjectorPlay doesn't exist"));
    }
    if (InputProjectorResetSelected != nullptr)
    {
        PEI->BindAction(InputProjectorResetSelected, ETriggerEvent::Triggered, this, &AMainCharacter::ProjectorPuzzleResetSelected);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputProjectorResetSelected doesn't exist"));
    }
    if (InputPadlockMinigameIncreaseProgress != nullptr)
    {
        PEI->BindAction(InputPadlockMinigameIncreaseProgress, ETriggerEvent::Triggered, this, &AMainCharacter::PadlockMinigameTap);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputPadlockMinigameIncreaseProgress doesn't exist"));
    }
    if (InputPadlockMinigameLeave != nullptr)
    {
        PEI->BindAction(InputPadlockMinigameLeave, ETriggerEvent::Triggered, this, &AMainCharacter::PadlockMinigameLeave);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputPadlockMinigameLeave doesn't exist"));
    }
    if (InputToggleInGameMenu != nullptr)
    {
        PEI->BindAction(InputToggleInGameMenu, ETriggerEvent::Triggered, this, &AMainCharacter::OpenCloseInGameMenu);
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("While binding action, InputToggleInGameMenu doesn't exist"));
    }
    

}

void AMainCharacter::ActivateCrawlWithAnimation(bool bAnimationEnabled)
{
    //Set animation condition for crawling to true
    if (MainCharAnimInstanceRef) MainCharAnimInstanceRef->SetIsCrawling(true);

    if (!bAnimationEnabled)
    {
        //Set the bool that camera animation should be skipped
        bCharacterWantsToSkipCrawlAnimation = true;
    }
    else
    {
        //Set the bool that camera animation should NOT be skipped
        bCharacterWantsToSkipCrawlAnimation = false;
    }

    //Call in-built Crouch function of Character to start crawl/crouch (As there is no inbuilt crawl)
    Crouch();
}

void AMainCharacter::DeactivateCrawlWithAnimation(bool bAnimationEnabled)
{
    //Set animation condition for crawling to false
    if (MainCharAnimInstanceRef) MainCharAnimInstanceRef->SetIsCrawling(false);

    if (!bAnimationEnabled)
    {
        //Set the bool that camera animation should be skipped
        bCharacterWantsToSkipCrawlAnimation = true;
    }
    else
    {
        //Set the bool that camera animation should NOT be skipped
        bCharacterWantsToSkipCrawlAnimation = false;
    }

    //Call in-built Crouch function of Character to start crawl/crouch (As there is no inbuilt crawl
    UnCrouch();
}

void AMainCharacter::Move(const FInputActionValue& Value)
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    if (Controller != nullptr)
    {
        const FVector2D MoveValue = Value.Get<FVector2D>();
        const FRotator MovementRotation(0, Controller->GetControlRotation().Yaw, 0);

        float JogSpeedFactor = (bIsJogging == true) ? JogSpeedMultiplier : 0.f;

        //Set Character Walk Speed
        GetCharacterMovement()->MaxWalkSpeed = MoveSpeed * (1 + JogSpeedFactor);
    
        //UE_LOG(LogTemp, Warning, TEXT("Is Jogging? %d, if so, speed factor is %f, move speed is %f"), bIsJogging, JogSpeedFactor, MoveSpeed);

        UWorld* TheWorld = GetWorld();
        if (TheWorld == nullptr)
        {
            UE_LOG(LogTemp, Error, TEXT("World could not be found while trying to move as main character"));
            return;
        }

        // Forward/Backward direction
        if (MoveValue.Y != 0.f)
        {
            //If crawling limit direction of moving in the direction actor was facing before "Crouch" was called
            if (bIsCrawling)
            {
                AddMovementInput(PreCrawlOrientation, MoveValue.Y);
            }
            else
            {
                // Get forward direction
                const FVector Direction = MovementRotation.RotateVector(FVector::ForwardVector);

                AddMovementInput(Direction, MoveValue.Y);

            }
        }

        // Right/Left direction
        if (MoveValue.X != 0.f)
        {
            // Get right vector
            const FVector Direction = MovementRotation.RotateVector(FVector::RightVector);

            AddMovementInput(Direction, MoveValue.X);
        }
    }
}

void AMainCharacter::Look(const FInputActionValue& Value)
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    if (Controller != nullptr)
    {
        //Check for existence of world
        UWorld* TheWorld = GetWorld();
        if (TheWorld == nullptr)
        {
            UE_LOG(LogTemp, Error, TEXT("World could not be found while trying to look around as main character"));
            return;
        }


        //If inspecting an actor
        if (bIsInspecting)
        {
            AInteractableActorMaster* InspectableActor = Cast<AInteractableActorMaster>(InteractableActorRef);
            if (InspectableActor && InspectableActor->InteractableInspectComponentRef && bIsInspectInputActivated)
            {
                const FVector2D RotateValue = Value.Get<FVector2D>();

                //Rotate the pitch and yaw
                FRotator MouseMovedRotator = FRotator(-1.f * RotateValue.Y * TheWorld->DeltaTimeSeconds * InspectSensitivity, -1.f * RotateValue.X * TheWorld->DeltaTimeSeconds * InspectSensitivity, 0.f);
                //Rotate the mesh
                InspectableActor->InteractableInspectComponentRef->RotateInspectedMesh(MouseMovedRotator);
            }
            //Return even if mesh wasn't rotated
            return;
        }


        //When not inspecting look around
        const FVector2D LookValue = Value.Get<FVector2D>();

        if (LookValue.X != 0.f)
        {
            AddControllerYawInput(LookValue.X * TheWorld->DeltaTimeSeconds * LookSensitivity * LookSensitivityScale);
        }

        if (LookValue.Y != 0.f)
        {
            AddControllerPitchInput(-LookValue.Y * TheWorld->DeltaTimeSeconds * LookSensitivity * LookSensitivityScale);
        }

        //UE_LOG(LogTemp, Display, TEXT("Current forward vector of actor: %s"), *(GetActorForwardVector().ToString()));
        //UE_LOG(LogTemp, Display, TEXT("Current rotation is :%s"), *(GetActorRotation().ToString()));
    } 
}

void AMainCharacter::OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust)
{
    Super::OnStartCrouch(HalfHeightAdjust, ScaledHalfHeightAdjust);
    //Offset camera position to original location
    //Set move speed to crawl speed
    MoveSpeed = CrawlSpeed;

    //Set Character Crouch/Crawl speed
    GetCharacterMovement()->MaxWalkSpeedCrouched = CrawlSpeed;

    //Set camera height to predetermined crawl height
    //GetCameraComponent()->SetRelativeLocation(CrawlCameraPosition);
    if (CameraManagerRef)
    {
        (bCharacterWantsToSkipCrawlAnimation) ? CameraManagerRef->SetCrawlCameraWithoutAnim() : CameraManagerRef->StartCrawlAnim();
    }
  
    bIsCrawling = true;

    /*UE_LOG(LogTemp, Display, TEXT("PostCrawlControl Rotation is: %s "), *(GetControlRotation().ToString()));
    UE_LOG(LogTemp, Display, TEXT("PpostCrawlCharacter Rotation is: %s "), *(GetActorRotation().ToString()));*/

}

void AMainCharacter::OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust)
{
    Super::OnEndCrouch(HalfHeightAdjust, ScaledHalfHeightAdjust);

    //Set camera height to predetermined standing height
    //GetCameraComponent()->SetRelativeLocation(OriginalCameraRelativeLoc);
    //UE_LOG(LogTemp, Warning, TEXT("After UnCrouch relative camera loc: %s"), *(GetCameraComponent()->GetRelativeLocation().ToString()));

    if (CameraManagerRef)
    {
        (bCharacterWantsToSkipCrawlAnimation) ? CameraManagerRef->SetUncrawlCameraWithoutAnim() : CameraManagerRef->StartUncrawlAnim();
    }

    bIsCrawling = false;

    //Set in the animation blueprint that crawling is false
    //if (MainCharAnimInstanceRef) MainCharAnimInstanceRef->SetIsCrawling(false);

    //Set move speed to walk speed
    MoveSpeed = WalkSpeed;
}

void AMainCharacter::ActivateJog()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    //If jogging not allowed, return
    if (!bIsJoggingAllowed) return;

    //Cannot jog if already jogging
    if (bIsJogging == true) return;

    //UE_LOG(LogTemp, Warning, TEXT("Started Jogging"));

    //Set jogging to true 
    bIsJogging = true;
    
    //Stop recovering stamina
    DeactivateJogStaminaRecovery();

    //Called every 0.1 seconds 
    GetWorldTimerManager().SetTimer(JogStaminaExpendLoopTimerHandle, [this]() {
        ExpendStamina();
        }, 0.1, true);
}

void AMainCharacter::DeactivateJog()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    //If already not jogging return
    if (bIsJogging == false) return;

    //UE_LOG(LogTemp, Warning, TEXT("Stopped Jogging"));

    //Set jogging to false
    bIsJogging = false;

    //Cancel expending stamina timer
    GetWorldTimerManager().ClearTimer(JogStaminaExpendLoopTimerHandle);

    //Start stamina recovery
    ActivateJogStaminaRecovery();
}

void AMainCharacter::CrawlInputReceived()
{
    //UE_LOG(LogTemp, Warning, TEXT("Crouch activated"));
    
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    //Actuall activate crawl with transition camera animation enabled
    ActivateCrawlWithAnimation(true);
    //UE_LOG(LogTemp, Warning, TEXT("Original crouch camera loc: %s"), *(OriginalCameraLoc.ToString()));
    //UE_LOG(LogTemp, Warning, TEXT("Original crouch relative camera loc: %s"), *(OriginalCameraRelativeLoc.ToString()));


    //UE_LOG(LogTemp, Warning, TEXT("Setting new offset location to : %s"), *(CrouchedCameraOrigRelativeLoc.ToString()));
    //GetCameraComponent()->SetRelativeLocation(CrouchedCameraOrigRelativeLoc);
    //UE_LOG(LogTemp, Warning, TEXT("After crouch camera loc: %s"), *(GetCameraComponent()->GetComponentLocation().ToString()));
    //UE_LOG(LogTemp, Warning, TEXT("After crouch relative camera loc: %s"), *(GetCameraComponent()->GetRelativeLocation().ToString()));*/


    //UE_LOG(LogTemp, Warning, TEXT("Calculated CameraCrouchOffset: %f"), CameraCrouchOffset);
    //Crouch();
      
}

void AMainCharacter::UncrawlInputReceived()
{
    //UE_LOG(LogTemp, Warning, TEXT("Crouch deactivated"));

    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    //Actually deactivate crawl with transition camera animation enabled
    DeactivateCrawlWithAnimation(true);
}

void AMainCharacter::ActivateInspectHold()
{
    //UE_LOG(LogTemp, Display, TEXT("Activate Inspect"));
    //If not inspecting don't activate
    if (!bIsInspecting) return;

    bIsInspectInputActivated = true;
    //UE_LOG(LogTemp, Display, TEXT("Inspect is being held"));
}

void AMainCharacter::DeactivateInspectHold()
{
    //UE_LOG(LogTemp, Display, TEXT("Deactivate Inspect"));
    //If not inspecting don't deactivate
    if (!bIsInspecting) return;

    bIsInspectInputActivated = false;
    //UE_LOG(LogTemp, Display, TEXT("Inspect was released"));

}

void AMainCharacter::ZoomInspectableActor(const FInputActionValue& Value)
{
    AInteractableActorMaster* InspectableActor = Cast<AInteractableActorMaster>(InteractableActorRef);
    if (InspectableActor == nullptr && InspectableActor->InteractableInspectComponentRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("Error, InspectableActor or InspectComponent in InspectableActor doesn't exist when Zooming on character"));
        return;
    }

    //+ve value is scroll up, -ve value is scroll down
    float ZoomValue = Value.Get<float>();
    //UE_LOG(LogTemp, Display, TEXT("Zoomed %f!!"), ZoomValue);

    //Zoom in or out depending on value of zoom
    (ZoomValue > 0.f) ? InspectableActor->InteractableInspectComponentRef->ZoomInspectedActor(true) : InspectableActor->InteractableInspectComponentRef->ZoomInspectedActor(false);
    
}

//This function is bound to the Interact key, and starts and stops interaction based on the state
void AMainCharacter::InteractWithActor()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    //Let game mode know that input was received to start cinematic if starting bench cinematic on start
    APrototypeGameMode* GameMode = Cast<APrototypeGameMode>(UGameplayStatics::GetGameMode(this));
    if (GameMode && GameMode->GetTriggerBenchCinematicOnPlay()) GameMode->SetIfInputReceivedForStartCinematic(true);

    //if cannot interact simply return
    if (!CheckIfCanInteract()) return;

    UE_LOG(LogTemp, Display, TEXT("Upon interact key press, is user interacting? %i"), bIsInteracting);
    if (bIsInteracting == false)
    {
        StartInteracting();
    }
    else
    {
        StopInteracting();
    }
}

void AMainCharacter::ToggleInventoryUI()
{
}

void AMainCharacter::SetInputContextToDefault()
{
    // Get the player controller
    APlayerController* PC = Cast<APlayerController>(GetController());

    // Get the local player subsystem
    UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer());
    // Clear out existing mapping, and add our mapping
    Subsystem->ClearAllMappings();
    Subsystem->AddMappingContext(DefaultInputMappingContext, 0);

    //UE_LOG(LogTemp, Warning, TEXT("Set input context to default in main character"));

    //Reset camera shake to default
    if (CamShakeCompRef) CamShakeCompRef->EnablePlayerCameraShake();
}

void AMainCharacter::SetInputContextToOnlyInspect()
{

    // Get the player controller
    APlayerController* PC = Cast<APlayerController>(GetController());

    // Get the local player subsystem
    UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer());
    // Clear out existing mapping, and add our mapping
    Subsystem->ClearAllMappings();
    Subsystem->AddMappingContext(OnlyInspectItemContext, 0);

    //UE_LOG(LogTemp, Warning, TEXT("Set input context to only inspect in main character"));
}

void AMainCharacter::SetInputContextToVentCrawling()
{
    // Get the player controller
    APlayerController* PC = Cast<APlayerController>(GetController());

    // Get the local player subsystem
    UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer());
    // Clear out existing mapping, and add our mapping
    Subsystem->ClearAllMappings();
    Subsystem->AddMappingContext(VentCrawlingInputContext, 0);
}

void AMainCharacter::SetInputContextToProjectorPuzzle()
{
    // Get the player controller
    APlayerController* PC = Cast<APlayerController>(GetController());

    // Get the local player subsystem
    UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer());
    // Clear out existing mapping, and add our mapping
    Subsystem->ClearAllMappings();
    Subsystem->AddMappingContext(ProjectorPuzzleContext, 0);

    //UE_LOG(LogTemp, Display, TEXT("Input context set to projector puzzle"));

    // Clear camera shake
    if (CamShakeCompRef) CamShakeCompRef->DisablePlayerCameraShake();

}

void AMainCharacter::SetInputContextToPadlockMinigame()
{
    // Get the player controller
    APlayerController* PC = Cast<APlayerController>(GetController());

    // Get the local player subsystem
    UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer());
    // Clear out existing mapping, and add our mapping
    Subsystem->ClearAllMappings();
    Subsystem->AddMappingContext(PadlockMinigameContext, 0);

    //Stop camera shake
    if (CamShakeCompRef) CamShakeCompRef->DisablePlayerCameraShake();
}

void AMainCharacter::ThrowObject()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    if (!bIsGrabbing) return;

    StoppedGrabbing();

    if (GrabberCompRef)
    {
        GrabberCompRef->Throw();
    }
}

void AMainCharacter::OpenCloseInGameMenu()
{
    if (!bIsAllowedToOpenInGameMenu)
    {
        UE_LOG(LogMainCharacter, Warning, TEXT("Warning! Not allowed to open in game menu"));
        return;
    }

    check(UIManagerRef);

    if (bIsInGameMenuOpen) //Close menu
    {
        //Close UI for in game menu
        UIManagerRef->CloseInGameMenuFromCharacterInput();
        //Unpause the game
        UGameplayStatics::SetGamePaused(this, false);

    }
    else // Open menu
    {
        //Display in game menu UI
        UIManagerRef->OpenInGameMenuFromCharacterInput();
        //Pause the game
        UGameplayStatics::SetGamePaused(this, true);
    }

    //Flip the flag each time
    bIsInGameMenuOpen = !bIsInGameMenuOpen;
}

void AMainCharacter::ProjectorPuzzleHover(const FInputActionValue& Value)
{
    if (ProjectorPuzzleActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting hover, ProjectorPuzzleActoRef is null"));
        return;
    }

    float IsHoverLeft = Value.Get<float>();

    //UE_LOG(LogTemp, Display, TEXT("Hovering value: %f"), IsHoverLeft);

    if (IsHoverLeft > 0.f)
    {
        //Tell puzzle to hover left
        ProjectorPuzzleActorRef->HoverToLeftReel();
    } 
    else
    {
        //Tell puzzle to hover right
        ProjectorPuzzleActorRef->HoverToRightReel();
    }
}

void AMainCharacter::ProjectorPuzzleSelectOrReplace()
{
    if (ProjectorPuzzleActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting Puzzle SelectOrReplace, ProjectorPuzzleActoRef is null"));
        return;
    }

    //Tell puzzle player is selecting or replacing
    ProjectorPuzzleActorRef->SelectOrReplaceCurrentReel();
}

void AMainCharacter::ProjectorPuzzleLeave()
{
    if (ProjectorPuzzleActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting PuzzleLeave, ProjectorPuzzleActoRef is null"));
        return;
    }

    //Leave the puzzle i.e manually left and puzzle not solved
    ProjectorPuzzleActorRef->ExitPuzzle(false);
}

void AMainCharacter::ProjectorPuzzlePlay()
{
    if (ProjectorPuzzleActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting PuzzlePlay, ProjectorPuzzleActoRef is null"));
        return;
    }

    //Play the current reel order and check if puzzle is solved
    ProjectorPuzzleActorRef->PlayCurrentReelOrder();

}

void AMainCharacter::ProjectorPuzzleResetSelected()
{
    if (ProjectorPuzzleActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting PuzzleResetSelected, ProjectorPuzzleActoRef is null"));
        return;
    }

    //Reset the selected effect on a reel
    ProjectorPuzzleActorRef->ClearCurrentSelectedReel();
}

void AMainCharacter::PadlockMinigameTap()
{
    if (PadlockMinigameActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting minigame tap, PadlockMinigameActorRef is null"));
        return;
    }

    PadlockMinigameActorRef->TapToIncreaseProgress();
}

void AMainCharacter::PadlockMinigameLeave()
{
    if (PadlockMinigameActorRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("When Inputting minigame tap, PadlockMinigameActorRef is null"));
        return;
    }

    PadlockMinigameActorRef->ManuallyLeaveMinigame();
}

void AMainCharacter::ResetCharacterState()
{
    bCanInteract = true;
    SetEnableInput(true);
    bIsInteracting = false;
    bIsInspecting = false;
    bIsGrabbing = false;
    bIsCrawling = false;
    bIsJogging = false;
    bIsRecoveringStamina = false;
    bIsInventoryOpen = false;

    //Reset current stamina
    CurrentStamina = MaxStamina;

    //Set expend stamina rate, here 10 is multiplied as the expend stamina func is called 10 times every second i.e once every 0.1 seconds
    ExpendStaminaRate = MaxStamina / (MaximumJogTime * 10);
    //Set recover stamina rate, here 10 is multiplied as the recover stamina func is called 10 times every second i.e once every 0.1 seconds
    RecoverStaminaRate = MaxStamina / (JogStaminaRecoveryTime * 10);

    //Reset to a state of walking
    MoveSpeed = WalkSpeed;

    //Reset actor to be in sync with PlayerController's rotation 
    SetControllerRotationYaw(true);

    ResetCameraViewLimit();
}

void AMainCharacter::ExpendStamina()
{   
    CurrentStamina -= ExpendStaminaRate;

    //UE_LOG(LogTemp, Warning, TEXT("Expended Stamina! Current Stamina is %f"), CurrentStamina);

    if (CurrentStamina <= 0.f) ExpendCompleteStamina();
}

void AMainCharacter::ExpendCompleteStamina()
{
    //Set stamina to 0
    CurrentStamina = 0.f;
    //Deactivate jogging
    DeactivateJog();

    //UE_LOG(LogTemp, Warning, TEXT("Expended Complete Stamina! Current Stamina is %f"), CurrentStamina);
    //TODO: Play exhausted sound effect
}

void AMainCharacter::RecoverStamina()
{
    CurrentStamina += RecoverStaminaRate;

    //UE_LOG(LogTemp, Warning, TEXT("Recovered Stamina! Current Stamina is %f"), CurrentStamina);

    if (CurrentStamina >= MaxStamina) RecoverCompleteStamina();
}

void AMainCharacter::RecoverCompleteStamina()
{
    //Set stamina to Max
    CurrentStamina = MaxStamina;
    //Deactivate jog stamina recovery
    DeactivateJogStaminaRecovery();

    //UE_LOG(LogTemp, Warning, TEXT("Recovered Complete Stamina! Current Stamina is %f"), CurrentStamina);
    //TODO: Play recovered sound effect
}

void AMainCharacter::ActivateJogStaminaRecovery()
{
    //UE_LOG(LogTemp, Warning, TEXT("Recovering Stamina..."));

    bIsRecoveringStamina = true;
     //Start timer for jog recovery time
    GetWorldTimerManager().SetTimer(JogStaminaRecoverLoopTimerHandle, [this]() {
        RecoverStamina();
        }, 0.1, true);
}

void AMainCharacter::DeactivateJogStaminaRecovery()
{
    //UE_LOG(LogTemp, Warning, TEXT("Stamina Recovered!"));
    bIsRecoveringStamina = false;

    //Stop recovering stamina
    GetWorldTimerManager().ClearTimer(JogStaminaRecoverLoopTimerHandle);
}

bool AMainCharacter::GetIsCrawling() const
{
    return bIsCrawling;
}

bool AMainCharacter::GetIsMoving() const
{
    if (CharMovementCompRef)
    {
        //If on ground and speed is > 0 
        if (CharMovementCompRef->IsMovingOnGround() && GetVelocity().Length() > 0)
        {
            return true;
        }
    }
    return false;
}

bool AMainCharacter::GetIsJogging() const
{
    if (CanJump() && GetVelocity().Length() >= GetJogSpeed()) return true;

    return false;
}

FVector AMainCharacter::GetCurrentVelocityAndSpeed(float& Speed)
{
    Speed = GetVelocity().Length();

    return GetVelocity();
}

bool AMainCharacter::GetIsCharacterMovingForward()
{

    FVector ForwardDir = GetActorForwardVector();
    FVector MovementDir = GetVelocity().GetSafeNormal2D();

    float DotProduct = FVector::DotProduct(ForwardDir, MovementDir);


    //If in same direction return moving forward
    if (DotProduct > 0) return true;

    return false;
}

float AMainCharacter::GetMoveSpeed() const
{
    return MoveSpeed;
}

float AMainCharacter::GetJogSpeed() const
{
    return WalkSpeed * (1 + JogSpeedMultiplier);
}

UCameraComponent* AMainCharacter::GetCharacterCameraComponent() const
{
    return GetComponentByClass<UCameraComponent>(); 
}

UCharacterCinematicsHandler* AMainCharacter::GetCinematicComponent() const
{
    return GetComponentByClass<UCharacterCinematicsHandler>();
}

UHealthComponent* AMainCharacter::GetHealthComponent() const
{
    return GetComponentByClass<UHealthComponent>();
}

void AMainCharacter::SetIsCharacterInteracting(bool bIsCharInteracting)
{
    //UE_LOG(LogTemp, Warning, TEXT("Character set to interacting %i"), bIsCharInteracting);
    bIsInteracting = bIsCharInteracting;
}

void AMainCharacter::SetCharacterHasBoltCutter(bool bHas)
{
    check(MCPlayerController);

    bHasBoltCutter = bHas;

    //Show the bolt cutter UI if character has it, or hide it if he doesn't/
    MCPlayerController->ShowBoltCutterUI(bHas);
}

void AMainCharacter::SetEnableInput(bool bEnableInput)
{
    //UE_LOG(LogTemp, Display, TEXT("Character input set to: %i"), bEnableInput);
    bIsCharacterInputEnabled = bEnableInput;
}

void AMainCharacter::SetPreCrawlOrientation(FVector Orientation)
{
    PreCrawlOrientation = Orientation;
}

void AMainCharacter::EnableCharacterCollision(bool bEnable)
{
    UCapsuleComponent* CharacterCapsuleCompRef = GetCapsuleComponent();

    if (bEnable)
    {
        CharacterCapsuleCompRef->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    }
    else
    {
        CharacterCapsuleCompRef->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
}

void AMainCharacter::SetIsAllowedOpenInGameMenu(bool bIsAllowed)
{
    bIsAllowedToOpenInGameMenu = bIsAllowed;
}

void AMainCharacter::SetMouseSensitivityScale(float NewSensitivity)
{
    LookSensitivityScale = NewSensitivity;
}

//void AMainCharacter::SetLevelSeqCineCam(ACineCameraActor* CamActor)
//{
//    LevelSeqCineCamActor = CamActor;
//}

AActor* AMainCharacter::GetInteractableActor()
{
    return InteractableActorRef;
}

void AMainCharacter::SetInteractableActor(AActor* InteractableActor)
{
    InteractableActorRef = InteractableActor;

#if WITH_EDITOR
    if (!InteractableActor) 
         { UE_LOG(LogMainCharacter, Warning, TEXT("Couldn't set interactable actor on MainCharacter, it was sent as null!")); }
    else 
        UE_LOG(LogMainCharacter, Display, TEXT("InteractableActorRef was set on MainCharacter to Actor: %s"), *(GetActorNameOrLabel()));
#endif
}

UCameraComponent* AMainCharacter::GetCameraComponent()
{
    return CameraCompRef;
}

void AMainCharacter::StoreComponentReferences()
{
    MCPlayerController = Cast<AMCPlayerController>(UGameplayStatics::GetPlayerController(this, 0));

    //Create the UI for inventory
    //InventoryScreenUI = CreateWidget(this, InventoryScreenClass);

    //Get potential sphere
    InteractionPotentialSphere = GetComponentByClass<USphereComponent>();

    if (InteractionPotentialSphere != nullptr)
    {
        //Set sphere component radius 
        InteractionPotentialSphere->SetSphereRadius(InteractPotentialRadius);
        //Set on overlap start and end functions
        InteractionPotentialSphere->OnComponentBeginOverlap.AddDynamic(this, &AMainCharacter::OverlapStarted);
        InteractionPotentialSphere->OnComponentEndOverlap.AddDynamic(this, &AMainCharacter::OverlapEnded);
    }

    //Get Camera component
    CameraCompRef = GetComponentByClass<UCameraComponent>();

    //Get grabber component
    GrabberCompRef = GetComponentByClass<UMainCharacterGrabber>();

    //Get character movement component
    CharMovementCompRef = GetComponentByClass<UCharacterMovementComponent>();

    //Store camera manager component
    CameraManagerRef = Cast<AMCCameraManager>(UGameplayStatics::GetPlayerCameraManager(this, 0));

    //Store camera shake component
    CamShakeCompRef = GetComponentByClass<UCharacterCameraShakeComponent>();

    if (GetMesh())
    {
        //Get anim instance
        MainCharAnimInstanceRef = Cast<UMainCharacterAnimInstance>(GetMesh()->GetAnimInstance());
    }

    //store Ui manager 
    if (MCPlayerController) UIManagerRef = MCPlayerController->GetComponentByClass<UUIManager>();
}

/**
* This function casts a trace from camera, with the intent to search for interactable objects
*/
void AMainCharacter::CastRayAndCheckInteractable()
{

    if (MCPlayerController == nullptr)
    {
        UE_LOG(LogTemp, Warning, TEXT("While casting a ray, player controller could not be found"));
        return;
    }

    FVector CameraLocation;
    FRotator CameraRotation;

    //Get the camera loc and rot
    MCPlayerController->GetPlayerViewPoint(CameraLocation, CameraRotation);

    //Get end location of trace
    FVector EndLocation = CameraLocation + (CameraRotation.Vector() * InteractDistance);

    //Ignore player
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(this);


    if (GetWorld() == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("While casting a ray, world could not be found"));
        return;
    }

    FHitResult TraceHitResult;

    //This collision channel is for general interactable actors
    bool bDidHit = GetWorld()->LineTraceSingleByChannel(TraceHitResult, CameraLocation, EndLocation, ECollisionChannel::ECC_GameTraceChannel1, Params);

    if (!bDidHit)
    {
        //UE_LOG(LogTemp, Warning, TEXT("Trace didn't hit anything"));
        // 
        //UE_LOG(LogTemp, Display, TEXT("Is character input enabled: %i "), bIsCharacterInputEnabled);
        //If stopped looking at actor, and has input enabled (eg: not currently in a cinematic), stop interacting
        if (InteractableActorRef && bIsCharacterInputEnabled)
        {
            //UE_LOG(LogTemp, Display, TEXT("Stopped interacting because ray trace couldn't find an interactable actor when raycasting"));

            //i.e stopped looking at the actor
            StopInteracting();

        }
        return;
    }

    //UE_LOG(LogTemp, Display, TEXT("Interactable Actor Hit, Name: %s"), *(TraceHitResult.GetActor()->GetName()));
  
    InteractableActorRef = TraceHitResult.GetActor();

    if (InteractableActorRef == nullptr) 
    {
        UE_LOG(LogTemp, Warning, TEXT("Despite hitting something, actor was found to be null"));
        return;
    }

    //Check if actor implements interact
    if (InteractableActorRef->Implements<UInteractItemInterface>())
    {
        //Shows interact key
        IInteractItemInterface::Execute_ShowInteractButton(InteractableActorRef);
        //Hide potential key 
        IInteractItemInterface::Execute_HideInteractPotential(InteractableActorRef);
    }

}

void AMainCharacter::StartedInspecting()
{
    bIsInspecting = true;

    SetInputContextToOnlyInspect();
}

void AMainCharacter::StoppedInspecting()
{

    //Stop inspect hold if inspect button was not left when stopping inspect
    DeactivateInspectHold();

    bIsInspecting = false;

    SetInputContextToDefault();
}

void AMainCharacter::StartedStoppedProjectorPuzzle(bool bHasStarted)
{
    if (bHasStarted)
    {
        SetInputContextToProjectorPuzzle();
        ProjectorPuzzleActorRef = Cast<AProjectorPuzzleActor>(InteractableActorRef);
    }
    else
    {
        SetInputContextToDefault();
        ProjectorPuzzleActorRef = nullptr;
    }
}

void AMainCharacter::StartedStoppedPadlockMinigame(bool bHasStarted)
{
    if (bHasStarted)
    {
        SetInputContextToPadlockMinigame();
        PadlockMinigameActorRef = Cast<APadlockCuttingMinigameActor>(InteractableActorRef);
    }
    else
    {
        SetInputContextToDefault();
        PadlockMinigameActorRef = nullptr;
    }
}

void AMainCharacter::StartVentCrawl(bool bStart)
{
    if (bStart)
    {
        bIsCrawling = true;

        //Store actor's forward vector after orientating it before vent animation begins to be used when moving when crawling
        PreCrawlOrientation = GetActorForwardVector();

        /*UE_LOG(LogTemp, Display, TEXT("PreCrawlControl Rotation is: %s "), *(GetControlRotation().ToString()));
        UE_LOG(LogTemp, Display, TEXT("PreCrawlCharacter Rotation is: %s "), *(GetActorRotation().ToString()));*/

        //Set new camera view rotation limits to crawl settings
        SetCrawlCameraViewLimit();

        //Stop actor rotation with control rotation changing
        SetControllerRotationYaw(false);

        //Call in-built crouch to make it seem that character is crawling
        ActivateCrawlWithAnimation(false);

        //Change input to only vent context
        SetInputContextToVentCrawling();
    }
    else
    {
        bIsCrawling = false;

        //Reset camera limitations to original (default limit)
        ResetCameraViewLimit();

        //Reset the orientation
        PreCrawlOrientation = FVector::ZeroVector;

        //Reallow actor to rotate with control 
        SetControllerRotationYaw(true);

        //Stop the crawl animation and start the idle animation
        DeactivateCrawlWithAnimation(false);

        //Change input context back to default
        SetInputContextToDefault();
    }
}

void AMainCharacter::ShowInteractPotentialOfActor(AActor* InteractableActor)
{
    //Check if over lapped actor implements interact item interface
    if (InteractableActor->Implements<UInteractItemInterface>())
    {
        //Show potential interact symbol
        IInteractItemInterface::Execute_ShowInteractPotential(InteractableActor);
        //Hide button symbol incase
        IInteractItemInterface::Execute_HideInteractButton(InteractableActor);
    }
}

void AMainCharacter::SetupCheckMaximumInteractableActorDistanceTimers(AInteractableActorMaster* InteractableActor)
{
    //PSEUDOCODE:
    // Push the actor and a timer into a TMap<InteractableActorMaster, FTimerHandle> 
    //Start a looped timer every 0.1 second
    //Timer checks if MinimumPotentialDistance is >= actual distance
    //If not, continue the timer
    //If true, Show Interact Potential and clear timer

    UE_LOG(LogMainCharacter, Display, TEXT("Setting up timers to check if the actor :%s  is within interactable distance every 0.1 second"), *(InteractableActor->GetActorNameOrLabel()));

    //Declare actor timer
    FTimerHandle InteractableActorTimer;
    //Declare and bind the respective timer delegate
    FTimerDelegate InteractableActorDelegate;
    InteractableActorDelegate.BindUFunction(this, "CheckInteractableActorDistanceTimerDelegate", InteractableActor);


    //Interact potential distance is not zero, we must now perform the logic to check if we're close enough to the actor
    InteractableActorDistanceCheckingTimerMap.Add(InteractableActor, InteractableActorTimer);

    //Set the timer to be called every 0.1 second to check whether actor is close enough
    GetWorldTimerManager().SetTimer(InteractableActorTimer, InteractableActorDelegate, 0.1, true);
}

void AMainCharacter::CheckInteractableActorDistanceTimerDelegate(AInteractableActorMaster* InteractableActor)
{
    //Get location of interactable actor
    FVector InteractableActorLocation = (InteractableActor->GetInteractUILocationComp()) ? InteractableActor->GetInteractUILocationComp()->GetComponentLocation() : InteractableActor->GetActorLocation();

    uint16 Distance = static_cast<uint16>(FMath::TruncToInt(FVector::Dist(InteractableActorLocation, GetActorLocation())));

    UE_LOG(LogMainCharacter, Display, TEXT("Checking if actor: %s is within interactable potential distance"), *(InteractableActor->GetActorNameOrLabel()));

    // Check if the actor Minimum Interact Potential Distance is less than the actual distance to actor
    if (Distance <= InteractableActor->GetMaximumInteractPotentialDistance() && InteractableActorDistanceCheckingTimerMap.Contains(InteractableActor))
    {
        //Show the potential UI
        ShowInteractPotentialOfActor(InteractableActor);

        //Get the timer associated with the actor, and removes the pair from the map
        FTimerHandle TimerHandleAssociatedWithActor = InteractableActorDistanceCheckingTimerMap.FindAndRemoveChecked(InteractableActor);

        //Clear the timer associated with the actor
        GetWorldTimerManager().ClearTimer(TimerHandleAssociatedWithActor);

        UE_LOG(LogMainCharacter, Display, TEXT("Actor was within interactable distance.. Reseting timer."));
    }
}

void AMainCharacter::ResetCameraViewLimit()
{
    if (CameraManagerRef)
    {
        CameraManagerRef->SetCameraYawLimit(OrigMinYaw, OrigMaxYaw);
        CameraManagerRef->SetCameraPitchLimit(OrigMinPitch, OrigMaxPitch);
    }
}

void AMainCharacter::SetCrawlCameraViewLimit()
{
    if (CameraManagerRef)
    {
        FRotator ActorRot = GetActorRotation();

        float MinYaw = ActorRot.Yaw - (CrawlYawLookArc / 2);
        float MaxYaw = ActorRot.Yaw + (CrawlYawLookArc / 2);


        //UE_LOG(LogTemp, Display, TEXT("New MinYaw: %f, MaxYaw: %f"), MinYaw, MaxYaw);
        CameraManagerRef->SetCameraYawLimit(MinYaw, MaxYaw);

        float MinPitch = ActorRot.Pitch - (CrawlPitchLookArc / 2);
        float MaxPitch = ActorRot.Pitch + (CrawlPitchLookArc / 2);

        //UE_LOG(LogTemp, Display, TEXT("New MinPitch: %f, MaxPitch: %f"), MinPitch, MaxPitch);
        CameraManagerRef->SetCameraPitchLimit(MinPitch, MaxPitch);
    }
}

void AMainCharacter::SetControllerRotationYaw(bool ShouldUse)
{
#if WITH_EDITOR
    UE_LOG(LogMainCharacter, Display, TEXT("Character Uses ControlRotationYaw Original: %i, New: %i"), bUseControllerRotationYaw, ShouldUse);
#endif

    bUseControllerRotationYaw = ShouldUse;
}

void AMainCharacter::SetFaceMeshOnlySeenByOwner(bool bEnable)
{
    check(FaceMeshComponent);

    UE_LOG(LogMainCharacter, Display, TEXT("Face mesh only seen by owner: %u"), bEnable);

    if (bEnable)
    {
        FaceMeshComponent->bOnlyOwnerSee = true;
        return;
    }

    FaceMeshComponent->bOnlyOwnerSee = false;
}

void AMainCharacter::SetFaceMeshVisible(bool bIsVisible)
{
    check(FaceMeshComponent);

    UE_LOG(LogMainCharacter, Display, TEXT("Face mesh set to visible: %u"), bIsVisible);

    if (bIsVisible)
    {
        FaceMeshComponent->SetVisibility(true);
        return;
    }

    FaceMeshComponent->SetVisibility(false);
}

void AMainCharacter::AttachCameraToSpine()
{
    UCameraComponent* CamRef = GetCharacterCameraComponent();

    if (!CamRef) UE_LOG(LogTemp, Error, TEXT("CameraComponentReference null when attaching it to spine"));

    if (CamRef->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepWorldTransform, FName("spine_03")))
    {
        UE_LOG(LogTemp, Display, TEXT("Camera attached to spine!"));
    }
    else 
        UE_LOG(LogTemp, Display, TEXT("Camera couldn't be attached to spine!"));

    
}

void AMainCharacter::AttachCameraToCapsule()
{
    UCameraComponent* CamRef = GetCharacterCameraComponent();

    if (!CamRef) UE_LOG(LogTemp, Error, TEXT("CameraComponentReference null when attaching it to capsule"));

    if (CamRef->AttachToComponent(GetCapsuleComponent(), FAttachmentTransformRules::KeepWorldTransform))
    {
        UE_LOG(LogTemp, Display, TEXT("Camera attached to capsule!"));
    }
    else 
        UE_LOG(LogTemp, Display, TEXT("Camera couldn't be attached to capsule!"));

}

void AMainCharacter::AllowPlayerJog(bool bIsAllowed)
{
    bIsJoggingAllowed = bIsAllowed;
}

void AMainCharacter::StartedGrabbing()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    bIsGrabbing = true;

    if (GrabberCompRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("Grabber component doesn't exist on main character when grabbing"));
        return;
    }

    GrabberCompRef->Grab();
}

void AMainCharacter::StoppedGrabbing()
{
    //If input disabled, no input
    if (!bIsCharacterInputEnabled) return;

    bIsGrabbing = false;

    if (GrabberCompRef == nullptr)
    {
        UE_LOG(LogTemp, Error, TEXT("Grabber component doesn't exist on main character when grabbing"));
        return;
    }

    GrabberCompRef->Release();
}

void AMainCharacter::OverlapStarted(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    //UE_LOG(LogTemp, Warning, TEXT("Overlap started"));
    // 
    UE_LOG(LogMainCharacter, Display, TEXT("Overlap Started with : %s"), *(OtherActor->GetActorNameOrLabel()));

    AInteractableActorMaster* InteractActorRef = Cast<AInteractableActorMaster>(OtherActor);

    if (InteractActorRef == nullptr) return;

    //For now show potential agnostic of max potential distance of actor
    ShowInteractPotentialOfActor(OtherActor);

    //TODO: Fix timer not clearing
    //If interact potential distance is 0, it means its unset, simply show potential UI (as actor has no requirement for distance)
    //if (InteractActorRef->GetMaximumInteractPotentialDistance() == 0)
    //{
    //    UE_LOG(LogMainCharacter, Display, TEXT("Interactable actor min. interact distance was not set, showing interact potential UI..."));

    //    ShowInteractPotentialOfActor(OtherActor);
    //    return;
    //} 

    ////Get location of interactable actor
    //FVector InteractableActorLocation = (InteractActorRef->GetInteractUILocationComp()) ? InteractActorRef->GetInteractUILocationComp()->GetComponentLocation() : InteractActorRef->GetActorLocation();

    //UE_LOG(LogMainCharacter, Display, TEXT("Distance to Interactable actor, :%u "), FMath::TruncToInt(FVector::Dist(InteractableActorLocation, GetActorLocation())));

    //uint16 Distance = static_cast<uint16>(FMath::TruncToInt(FVector::Dist(InteractableActorLocation, GetActorLocation())));
    //

    //// Check if the distance is less than the actor's maximum Interact Potential Distance 
    //if (Distance <= InteractActorRef->GetMaximumInteractPotentialDistance())
    //{
    //    UE_LOG(LogMainCharacter, Display, TEXT("Distance to Interactable actor, :%u was within maximum interactable distance: %u , showing interact potential UI..."), Distance, InteractActorRef->GetMaximumInteractPotentialDistance());

    //    ShowInteractPotentialOfActor(OtherActor);
    //    return;
    //}

    ////Setups timers as min interact distance is non-zero, and we must tick to check if the actor is within the required distance
    //SetupCheckMaximumInteractableActorDistanceTimers(InteractActorRef);
}

void AMainCharacter::OverlapEnded(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
    UE_LOG(LogMainCharacter, Display, TEXT("Overlap ended for actor: %s"), *(OtherActor->GetActorNameOrLabel()));
    
    //Check if actor exists as key in the TMap<InteractableActorMaster, FTimerHandle> 
    //If it did, clear the corresponding timerhandle, and delete this key,value pair from the map
    AInteractableActorMaster* InteractableActor = Cast<AInteractableActorMaster>(OtherActor);

    //TODO: Fix timer not clearing
    //if (InteractableActor && InteractableActorDistanceCheckingTimerMap.Contains(InteractableActor))
    //{
    //    //Find timer handle associated with interactable actor and remove it
    //    FTimerHandle FoundTimerHandle = InteractableActorDistanceCheckingTimerMap.FindAndRemoveChecked(InteractableActor);

    //    //Clear the timer for that handle
    //    GetWorldTimerManager().ClearTimer(FoundTimerHandle);
    //}

    //Hide all potental interactability
    if (OtherActor->Implements<UInteractItemInterface>())
    {
        //Hide potential interact symbol
        IInteractItemInterface::Execute_HideInteractPotential(OtherActor);
        //Hide button interact symbol incase
        IInteractItemInterface::Execute_HideInteractButton(OtherActor);
        //Only end interaction if actor is not the vent (as it calls its end interaction by itself) [PATCH]
        if(!OtherActor->ActorHasTag(FName("Vent"))) // End interaction
            IInteractItemInterface::Execute_EndInteraction(OtherActor);
            
    }
}

void AMainCharacter::StartInteracting()
{
    if (InteractableActorRef != nullptr)
    {
        //UE_LOG(LogTemp, Warning, TEXT("Start interacting"));
        /*bIsInteracting = true;*/
        //Check if actor implements interact
        if (InteractableActorRef->Implements<UInteractItemInterface>())
        {
            // Interact with the actor
            IInteractItemInterface::Execute_Interact(InteractableActorRef);
        }
    }

    //UE_LOG(LogMainCharacter, Display, TEXT("Character Start Interacting!"));
}

void AMainCharacter::StopInteracting()
{
    //UE_LOG(LogTemp, Warning, TEXT("Stop interacting"));
    if (InteractableActorRef != nullptr)
    {
        //Check if actor implements interact
        if (InteractableActorRef->Implements<UInteractItemInterface>())
        {
            //UE_LOG(LogTemp, Warning, TEXT("Interactable actor implements interact"));
            // Hide Interact Button 
            IInteractItemInterface::Execute_HideInteractButton(InteractableActorRef);
            // End interaction
            IInteractItemInterface::Execute_EndInteraction(InteractableActorRef);
            //Show interact potential 
            IInteractItemInterface::Execute_ShowInteractPotential(InteractableActorRef);
        }

        InteractableActorRef = nullptr;
    }

    //UE_LOG(LogMainCharacter, Display, TEXT("Character StopInteracting!"));
}

void AMainCharacter::StopInteracting(AInteractableActorMaster* ActorToStopInteraction)
{
    /*UE_LOG(LogTemp, Warning, TEXT("Stop interacting with Actor Parameter provided"));*/
    if (ActorToStopInteraction != nullptr)
    {
        //Check if actor implements interact
        if (ActorToStopInteraction->Implements<UInteractItemInterface>())
        {
            //UE_LOG(LogTemp, Warning, TEXT("Interactable actor implements interact"));
            // Hide Interact Button 
            IInteractItemInterface::Execute_HideInteractButton(ActorToStopInteraction);
            // End interaction
            IInteractItemInterface::Execute_EndInteraction(ActorToStopInteraction);
            //Show interact potential 
            IInteractItemInterface::Execute_ShowInteractPotential(ActorToStopInteraction);
        }
    }
}

bool AMainCharacter::CheckIfCanInteract()
{
    if (bCanInteract && InteractableActorRef)
    {
        //UE_LOG(LogMainCharacter, Display, TEXT("Character Can Interact! Currently InteractableActor is : %s"), *(InteractableActorRef->GetActorNameOrLabel()));
        return true;
    }

    //UE_LOG(LogMainCharacter, Display, TEXT("Character Cannot Interact!"));
    return false;
}

