// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "../Interfaces/InteractionMasterInterface.h"
#include "InteractableActorMaster.generated.h"

class UWidgetComponent;
class AHorrorEventMaster;

DECLARE_LOG_CATEGORY_EXTERN(LogInteractableActor, Log, All);


//This class handles general interaction for general interact components (Text and Inspect)
UCLASS()
class PROJECTANIL_API AInteractableActorMaster : public AActor, public IInteractItemInterface
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AInteractableActorMaster();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void Interact_Implementation() override;
	virtual void EndInteraction_Implementation() override;
	virtual void ShowInteractPotential_Implementation() override;
	virtual void HideInteractPotential_Implementation() override;
	virtual void ShowInteractButton_Implementation() override;
	virtual void HideInteractButton_Implementation() override;

	//Getters
	UStaticMeshComponent* GetActorMesh();
	USceneComponent* GetRootComponent();
	uint16 GetMaximumInteractPotentialDistance() const { return MaximumInteractPotentialDistance; }
	USceneComponent* GetInteractUILocationComp() const { return InteractUILocation;  }
	bool GetIsActorBeingInteractedWith() const; 

	class UInteractableTextComponent* InteractableTextComponentRef;
	class UInteractableInspectComponent* InteractableInspectComponentRef;

	//Public Setters
	//Sets whether the actor can be interacted with or not
	UFUNCTION (BlueprintCallable) void SetInteractability(bool bCanInteract);
	UFUNCTION (BlueprintCallable) void SetCanShowInteractionUI(bool bCanShow);
	UFUNCTION (BlueprintCallable) void ShowInteractionUI(bool bShow);

protected:

	UPROPERTY(VisibleAnywhere)
	USceneComponent* Root;

	UPROPERTY(EditDefaultsOnly) TSubclassOf<AHorrorEventMaster> HorrorEventClass = nullptr;
	UPROPERTY() AHorrorEventMaster* HorrorEventToPlay = nullptr;

	UPROPERTY(VisibleAnywhere)
	USceneComponent* InteractUILocation;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh Settings", meta = (AllowPrivateAccess = "true"))
	UStaticMeshComponent* ActorMesh;

	//The maximum distance required to "potentially" be able to interact with the actor
	UPROPERTY(EditDefaultsOnly, Category = "Interact Settings") uint16 MaximumInteractPotentialDistance = 0;

	UPROPERTY(VisibleAnywhere, meta = (AllowPrivateAccess = "true"))
	UWidgetComponent* InteractKeyUI;

	UPROPERTY(VisibleAnywhere, meta = (AllowPrivateAccess = "true"))
	UWidgetComponent* InteractPotentialUI;

	bool bIsInteracting = false;
	bool bCanShowInteractionUI = true;
	bool bIsShowingInteractPotential = false;
	bool bIsShowingInteractKey = false;
	bool bCanBeInteractedWith = true;

	class AMCPlayerController* MCPlayerController;
	class AMainCharacter* MainCharRef;

	//Setters
	//This sets on the current actor as well as the main character that the player is interacting or not
	void SetIsInteracting(bool isInteracting);

private:

	void StorePlayerControllerRef();
	void StoreMainCharacterRef();
	

};
