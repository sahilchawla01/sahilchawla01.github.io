// Fill out your copyright notice in the Description page of Project Settings.


#include "HealthComponent.h"
#include "../../DamageTypes/PrototypeFinalKillDamageType.h"
#include "Kismet/GameplayStatics.h"
#include "../../PrototypeGameMode.h"
#include "../../Events/HorrorEventMaster.h"

// Sets default values for this component's properties
UHealthComponent::UHealthComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UHealthComponent::BeginPlay()
{
	Super::BeginPlay();

	CurrentHealth = MaxHealth;
	CurrentHealthState = EHealthState::Healthy;

	//Assign delegate to call health func on any damage taken
	GetOwner()->OnTakeAnyDamage.AddDynamic(this, &UHealthComponent::DamageTaken);
	
}


// Called every frame
void UHealthComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UHealthComponent::EvaluateAndSetHealthState(const UDamageType* DamageType)
{
	//Check if damage given is the final killing damage in the prototype level
	bool bIsFinalKillDamage = false;
	if (DamageType && Cast<UPrototypeFinalKillDamageType>(DamageType))
	{
		bIsFinalKillDamage = true;
	}

	//Set currentl health state according to respective thresholds
	if (CurrentHealth >= HealthyThreshold)
	{
		//Healthy
		CurrentHealthState = EHealthState::Healthy;
		//TODO: Declare a delegate such that other components know that the current health state has changed
	}
	else if (CurrentHealth >= InjuredThreshold)
	{
		//Injured
		CurrentHealthState = EHealthState::Injured;
	}
	else if (CurrentHealth > 0.f)
	{
		//Critical
		CurrentHealthState = EHealthState::Critical;
	}
	else
	{
		//Dead
		CurrentHealthState = EHealthState::Dead;

		APrototypeGameMode* GameMode = Cast<APrototypeGameMode>(UGameplayStatics::GetGameMode(GetWorld()));

		check(GameMode);
		if (bIsFinalKillDamage)
		{
			//Player was killed at the final cinematic opening the double doors
			GameMode->PlayerKilledAtFinalDoor();
			return;
		}

		//player has died through other means
		GameMode->PlayerKilled();

	}
}

void UHealthComponent::SpawnOnDamageHorrorEvent()
{
	//Spawn horror event
	if (DamagedHorrorEventClass)
	{
		FTransform SpawnTransform;
		SpawnTransform.SetLocation(GetOwner()->GetActorLocation());
		SpawnTransform.SetRotation(GetOwner()->GetActorRotation().Quaternion());

		const FActorSpawnParameters SpawnParams;

		//This means that the event was spawned and has not yet been destroyed, if that is the case, stop & destroy earlier event and continue
		if (DamagedHorrorEventToPlay)
		{
			DamagedHorrorEventToPlay->StopEvents();
		}

		DamagedHorrorEventToPlay = GetWorld()->SpawnActor<AHorrorEventMaster>(DamagedHorrorEventClass, SpawnTransform, SpawnParams);

		if (!DamagedHorrorEventToPlay) UE_LOG(LogTemp, Warning, TEXT("HorrorEvent actor couldn't be spawned when taking damage"));
	}
	else
		UE_LOG(LogTemp, Warning, TEXT("Damage Taken! HorrorEventClass was not assigned in health component on main character"));
}

void UHealthComponent::SpawnOnHealHorrorEvent()
{
	//Spawn horror event
	if (HealHorrorEventClass)
	{
		FTransform SpawnTransform;
		SpawnTransform.SetLocation(GetOwner()->GetActorLocation());
		SpawnTransform.SetRotation(GetOwner()->GetActorRotation().Quaternion());

		const FActorSpawnParameters SpawnParams;

		//This means that the event was spawned and has not yet been destroyed, if that is the case, stop & destroy earlier event and continue
		if (HealHorrorEventToPlay)
		{
			HealHorrorEventToPlay->StopEvents();
		}

		HealHorrorEventToPlay = GetWorld()->SpawnActor<AHorrorEventMaster>(HealHorrorEventClass, SpawnTransform, SpawnParams);

		if (!HealHorrorEventToPlay) UE_LOG(LogTemp, Warning, TEXT("HorrorEvent actor couldn't be spawned when healed"));
	}
	else
		UE_LOG(LogTemp, Warning, TEXT("Healed! HorrorEventClass was not assigned in health component on main character"));
}

void UHealthComponent::DamageTaken(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* Instigator, AActor* DamageCauser)
{
	//If damage is non-existent return
	if (Damage <= 0.f) return;

	//If already dead return
	if (bIsDead) return;

	//Reduce health
	if (CheckIfDamageKillsPlayer(Damage))
		CurrentHealth = 0.f;
	else 
		CurrentHealth -= Damage;

	EHealthState PrevHealthState = GetCurrentHealthState();

	//Check the state of current health
	EvaluateAndSetHealthState(DamageType);

	//Let all subscribed components know that damage was taken
	OnHealthDamageDelegate.Broadcast(CurrentHealth, PrevHealthState, GetCurrentHealthState());
	
	//Give audio feedback on damage taken
	SpawnOnDamageHorrorEvent();
}

void UHealthComponent::Heal(float HealAmount)
{
	//If HealAmouunt is non-existent return
	if (HealAmount <= 0.f) return;

	//If already dead return
	if (bIsDead) return;

	//Heal health
	CurrentHealth += HealAmount;

	//Clamp health incase it goes above max health
	CurrentHealth = FMath::Clamp(CurrentHealth, 0.f, MaxHealth);

	EHealthState PrevHealthState = GetCurrentHealthState();

	//Check the state of current health
	EvaluateAndSetHealthState();

	//Let all subscribed components know that actor was healed
	OnHealthHealDelegate.Broadcast(CurrentHealth, PrevHealthState, GetCurrentHealthState());

	SpawnOnHealHorrorEvent();
}

const bool UHealthComponent::CheckIfDamageKillsPlayer(const float Damage)
{
	if (CurrentHealth - Damage <= 0.f) return true;

	return false;
}

