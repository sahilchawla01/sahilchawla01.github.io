// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "InputActionValue.h"
#include "MainCharacter.generated.h"

class UInputAction;
class UUserWidget;
class UEnhanchedLocalPlayerSubsystem;
class UCameraComponent;
class AMCPlayerController;
class AInteractableActorMaster;
class AProjectorPuzzleActor;
class USphereComponent;
class UMainCharacterGrabber;
class UCharacterCinematicsHandler;
class APadlockCuttingMinigameActor;
class UCharacterCameraShakeComponent;
class UHealthComponent;
//class ACineCameraActor;

DECLARE_LOG_CATEGORY_EXTERN(LogMainCharacter, Log, All);

/*
* This is the character responsible for being the conduit for user input to interact with the world
* 
* 
** Interacting:
* InteractableActorRef is the actor that is being interacted with, set through two methods:
* 1) RayCasting: A ray is casted from the character and if it intersects with an actor that is an interactable actor, it stores it in InteractableActorRef
* 2) Setting from SetInteractableActor(): This is done when the character interacts with an interactable actor not directly (for example: interacting by playing a cinematic from beginplay)
*/
UCLASS()
class PROJECTANIL_API AMainCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AMainCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	//This is called when crouch is started
	virtual void OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
	//This is called when crouch ends
	virtual void OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);

#pragma region /** Input Assets*/
protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Contexts") class UInputMappingContext* DefaultInputMappingContext;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Contexts") UInputMappingContext* OnlyInspectItemContext;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Contexts") UInputMappingContext* VentCrawlingInputContext;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Contexts| Minigames") UInputMappingContext* PadlockMinigameContext;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Contexts| Puzzles") UInputMappingContext* ProjectorPuzzleContext;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputToggleInGameMenu;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputMove;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputLook;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputJogActivate;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputJogDeactivate;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputInteract;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputToggleInventory;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputGrab;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputRelease;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputThrowObject;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputCrawlActivate;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputCrawlDeactivate;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputInspectActivate;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputInspectDeactivate;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions") UInputAction* InputZoom;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Minigame") UInputAction* InputPadlockMinigameIncreaseProgress;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Minigame") UInputAction* InputPadlockMinigameLeave;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Projector Puzzle") UInputAction* InputProjectorHoverLeftRight;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Projector Puzzle") UInputAction* InputProjectorSelectOrReplace;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Projector Puzzle") UInputAction* InputProjectorLeavePuzzle;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Projector Puzzle") UInputAction* InputProjectorPlay;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enhanced Input | Actions| Projector Puzzle") UInputAction* InputProjectorResetSelected;

#pragma endregion
#pragma region /** Input Functions */

public:
	//In-game menu functions
	void OpenCloseInGameMenu();

private:
	void Move(const FInputActionValue& Value);
	void Look(const FInputActionValue& Value);
	void ActivateJog();
	void DeactivateJog();
	void CrawlInputReceived();
	void UncrawlInputReceived();
	void ActivateInspectHold();
	void DeactivateInspectHold();
	void ZoomInspectableActor(const FInputActionValue& Value);
	void InteractWithActor();
	void ToggleInventoryUI();
	void SetInputContextToDefault();
	void SetInputContextToOnlyInspect();
	void SetInputContextToVentCrawling();
	void SetInputContextToProjectorPuzzle();
	void SetInputContextToPadlockMinigame();
	void ThrowObject();

	

	//Puzzle inputs
	void ProjectorPuzzleHover(const FInputActionValue& Value);
	void ProjectorPuzzleSelectOrReplace();
	void ProjectorPuzzleLeave();
	void ProjectorPuzzlePlay();
	void ProjectorPuzzleResetSelected();

	//Minigame inputs
	void PadlockMinigameTap();
	void PadlockMinigameLeave();
public:
	void StartedGrabbing();
	void StoppedGrabbing();
#pragma endregion
#pragma region /** Player Settings */
	/** This speed is given in cm/s */
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float WalkSpeed = 100.f;
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float LookSensitivity = 1.5f;
	/** The multiplier value represents how much faster the jog is relative to the move speed eg: if multiplier is 0.25, jog is 25% faster*/
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float JogSpeedMultiplier = 0.1f;
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float MaxStamina= 100.f;
	// Maximum time character can jog (in seconds)
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float MaximumJogTime = 2.f;
	// Time required by character to take a break before jogging again
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement")
	float JogStaminaRecoveryTime = 2.f;
	//This value sets the speed of crawling
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement | Crawling")
	float CrawlSpeed = 50.f;
	//The total arc (in degrees) within which looking is limited when crawling (Yaw)
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement | Crawling")
	float CrawlYawLookArc = 100.f;
	//The total arc (in degrees) within which looking is limited when crawling (Pitch)
	UPROPERTY(EditAnywhere, Category = "Player Settings | Player Movement | Crawling")
	float CrawlPitchLookArc = 40.f;
	// The reach of the player in centimetre
	UPROPERTY(EditAnywhere, Category = "Player Settings | Interaction")
	int InteractDistance = 180;
	// The space within which item potential interaction can be seen
	UPROPERTY(EditAnywhere, Category = "Player Settings | Interaction")
	float InteractPotentialRadius= 250.f;
	//The sensitivty at which player wants to rotate and inspect an item
	UPROPERTY(EditAnywhere, Category = "Player Settings | Interaction")
	float InspectSensitivity = 40.f;
	UPROPERTY(EditAnywhere, Category = "Player Settings | Camera")
	FVector CrawlCameraPosition = FVector(0.f, 0.f, -35.f);
	
#pragma endregion

#pragma region /** Player State Variables */
private:
	bool bCanInteract = true;
	bool bIsCharacterInputEnabled = true;
	bool bIsInteracting = false;
	//This is the bool that is true/false when mouse1 is being held while inspecting, to allow for inspect rotation
	bool bIsInspectInputActivated = false;
	//This is used when crawling, to ensure that if true, the camera animation of crawling and uncrawling is skipped
	bool bCharacterWantsToSkipCrawlAnimation = false;
	bool bIsInspecting = false;
	bool bIsGrabbing = false;
	bool bIsCrawling = false;
	bool bIsJogging = false;
	bool bIsJoggingAllowed = true;
	bool bIsRecoveringStamina = false;
	bool bIsInventoryOpen = false;
	bool bHasBoltCutter = false;
	bool bIsInGameMenuOpen = false;
	bool bIsAllowedToOpenInGameMenu = false;
	float LookSensitivityScale = 1.5f;
	float CurrentStamina = 100.f;
	float ExpendStaminaRate = 1.f;
	float RecoverStaminaRate = 1.f;
	float TiredPercentage = 0.f;
	//The speed at which the character can current move
	float MoveSpeed = 100.f;
	//This timer handle is bound to calling the expending of stamina
	FTimerHandle JogStaminaExpendLoopTimerHandle;
	//This timer handle is bound to calling the recovering of stamina
	FTimerHandle JogStaminaRecoverLoopTimerHandle;
	//This map is used to associate an interactable actor with a timer, which constantly checks whether the actor is close enough to the main char or not
	TMap<AInteractableActorMaster*, FTimerHandle> InteractableActorDistanceCheckingTimerMap;
#pragma endregion

#pragma region /** Player State Functions */
public:
	//Used to "Crawl" with or without animation smoothening the transition camera animation 
	void ActivateCrawlWithAnimation(bool bAnimationEnabled);
	//Used to "UnCrawl" with or without animation smoothening the transition camera animation 
	void DeactivateCrawlWithAnimation(bool bAnimationEnabled);
	void SetCrawlCameraViewLimit();
	//Whether actor should rotate with control rotation or not
	void SetControllerRotationYaw(bool ShouldUse);
	void SetFaceMeshOnlySeenByOwner(bool bEnable);
	void SetFaceMeshVisible(bool bIsVisible);
	//Attaches the main camera on character to spine_03 
	UFUNCTION(BlueprintCallable) void AttachCameraToSpine();
	//Attaches the main camera on character to capsule (for normal movement)
	UFUNCTION(BlueprintCallable) void AttachCameraToCapsule();
	UFUNCTION(BlueprintCallable) void AllowPlayerJog(bool bIsAllowed);
private:
	void ResetCharacterState();
	//This function is called every 0.1 seconds to expend stamina
	void ExpendStamina();
	//This function is called when the stamina is completely empty
	void ExpendCompleteStamina();
	//This function is called every 0.1 seconds to recover stamina
	void RecoverStamina();
	//This function is called when the stamina is completely filled
	void RecoverCompleteStamina();
	//This function activates the stamina recovery 
	void ActivateJogStaminaRecovery();
	//This function deactivates the stamina recovery 
	void DeactivateJogStaminaRecovery();
	void ResetCameraViewLimit();
#pragma endregion

#pragma region /** Getters */
	public:
		//Returns whether the character is crawling or not
		bool GetIsCrawling() const;
		//Returns whether the character is moving on the ground or not
		bool GetIsMoving() const;
		//Returns whether the character is jogging or not
		bool GetIsJogging() const;
		//Returns the current velocity and sets the speed variable to the character's speed
		FVector GetCurrentVelocityAndSpeed(float& Speed);
		//True: Character Moving Forward, False: Character Moving Backward
		bool GetIsCharacterMovingForward();
		//Returns the normal moving speed of the character and !! NOT THE CURRENT MOVE SPEED!!
		float GetMoveSpeed() const;
		//Returns the normal jogging speed of the character and !! NOT THE CURRENT MOVE SPEED!!
		float GetJogSpeed() const;
		//Returns whether the character is currently recovering stamina or not
		bool GetIsRecoveringStamina() const { return bIsRecoveringStamina; }
		//Returns whether the character is currently interacting or not
		bool GetIsInteracting() const { return bIsInteracting;  }
		UFUNCTION(BlueprintCallable) bool GetHasBoltCutter() const { return bHasBoltCutter; }
		//Get the camera component
		UCameraComponent* GetCharacterCameraComponent() const;
		//Return the vector that defines the original relative location of camera in crouched state before crouch anim occurs
		FVector const GetCrouchedCameraOrigRelativePosition() { return CrouchedCameraOrigRelativeLoc;  }
		FVector const GetOriginalCameraRelativeLoc() { return OriginalCameraRelativeLoc; }
		FVector const GetCrawlCameraRelativeLoc() { return CrawlCameraRelativeLoc; }
		float const GetCameraCrouchOffset() { return CameraCrouchOffset;  }
		//Returns the cinematic component
		UCharacterCinematicsHandler* GetCinematicComponent() const;
		//Returns sensitivity scale that affects only in-game looking
		float GetMouseSensitivityScale() const { return LookSensitivityScale; }
		//ACineCameraActor* const GetLevelSeqCineCam() { return LevelSeqCineCamActor; }
		bool GetIsAllowedOpenInGameMenu() const { return bIsAllowedToOpenInGameMenu;  }
		bool GetIsCharacterInputEnabled() const { return bIsCharacterInputEnabled; }
		UHealthComponent* GetHealthComponent() const;
		
#pragma endregion

#pragma region /** Setters */
	public:
		void SetIsCharacterInteracting(bool bIsCharInteracting);
		UFUNCTION(BlueprintCallable) void SetCharacterHasBoltCutter(bool bHas);
		//This function enables/disables the input for character including input such as locomotion, looking around, etc.
		void SetEnableInput(bool bEnableInput);
		void SetPreCrawlOrientation(FVector Orientation);
		void EnableCharacterCollision(bool bEnable);
		void SetIsAllowedOpenInGameMenu(bool bIsAllowed);
		//Sets LookSensitivityScale for in-game use, usually called through the value changing in UI
		UFUNCTION() void SetMouseSensitivityScale(float NewSensitivity);
		//UFUNCTION(BlueprintCallable) void SetLevelSeqCineCam(ACineCameraActor* CamActor);
#pragma endregion

#pragma region /** Generic Reference and Component Variables */
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Component References") TObjectPtr<USkeletalMeshComponent> FaceMeshComponent;
private:
	//This cine cam actor is used to obtain camera detail within a level sequence 
	//UPROPERTY() ACineCameraActor* LevelSeqCineCamActor
	UPROPERTY() AMCPlayerController* MCPlayerController;
	UPROPERTY() AActor* InteractableActorRef;
	UPROPERTY() AProjectorPuzzleActor* ProjectorPuzzleActorRef;
	UPROPERTY() APadlockCuttingMinigameActor* PadlockMinigameActorRef;
	
	UPROPERTY() UCharacterMovementComponent* CharMovementCompRef;
	UPROPERTY() USphereComponent* InteractionPotentialSphere;
	UPROPERTY() UCameraComponent* CameraCompRef;
	UPROPERTY() UMainCharacterGrabber* GrabberCompRef; 
	UPROPERTY() UCharacterCameraShakeComponent* CamShakeCompRef;
	UPROPERTY() class UMainCharacterAnimInstance* MainCharAnimInstanceRef;
	UPROPERTY() class AMCCameraManager* CameraManagerRef;
	UPROPERTY() class UUIManager* UIManagerRef = nullptr;

#pragma endregion

#pragma region /** Generic Reference and Component Getters and Setters */
public:
	UMainCharacterAnimInstance* GetMainCharAnimInstance() { return MainCharAnimInstanceRef; };
	void SetInteractableActor(AActor* InteractableActor);

	AActor* GetInteractableActor();
	UCameraComponent* GetCameraComponent();
#pragma endregion

#pragma region /** UI References */
	UPROPERTY(EditDefaultsOnly) TSubclassOf<UUserWidget> InventoryScreenClass;

	UPROPERTY() UUserWidget* InventoryScreenUI;
#pragma endregion

#pragma region /** Initialiser Functions*/
	void StoreComponentReferences();
#pragma endregion

#pragma region /** Player Interact Functions */
	void CastRayAndCheckInteractable();
	UFUNCTION(Category = "Overlap")
	void OverlapStarted(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION(Category = "Overlap")
	void OverlapEnded(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	void StartInteracting();
	//This interaction mainly works when looking at something then looking away (raycasting)
	void StopInteracting();
	//This interaction is for cases such as when a level sequence stops 
	void StopInteracting(AInteractableActorMaster* ActorToStopInteraction);

	//If can interact and is not already having the ability to interact, cast ray
	bool CheckIfCanInteract();

public:
	void StartedInspecting();
	void StoppedInspecting();
	//Important function that switches input mapping context between Projector Puzzle and Default Context
	void StartedStoppedProjectorPuzzle(bool bHasStarted);
	//Important function that switches input mapping context between Padlock Minigame and Default Context
	void StartedStoppedPadlockMinigame(bool bHasStarted);
	//IMP!: To be called once level sequence entering/exiting vent is done |Switches input mapping context between Vent Crawl and Default Context
	void StartVentCrawl(bool bStart);

private:
	void ShowInteractPotentialOfActor(AActor* InteractableActor);
	//This sets up the timers to check if an interactable actor is within interactable distance or not
	void SetupCheckMaximumInteractableActorDistanceTimers(AInteractableActorMaster* InteractableActor);
	//Checks if interactable actor is within range, if so, shows 
	UFUNCTION() void CheckInteractableActorDistanceTimerDelegate(AInteractableActorMaster* InteractableActor);

#pragma endregion

#pragma region /** Miscellaneous Variables*/
	private:
		FVector OriginalCameraLoc;
		FVector OriginalCameraRelativeLoc;
		FVector CrouchedCameraOrigRelativeLoc;
		//The direction in which character is facing before crawling
		FVector PreCrawlOrientation = FVector::Zero();
		//The position camera should be in when crawling
		FVector CrawlCameraRelativeLoc = FVector::Zero();

		float OrigMinYaw = 0.f;
		float OrigMaxYaw = 359.99f;
		float OrigMinPitch = -89.9f;
		float OrigMaxPitch = 89.9f;
		float CameraCrouchOffset = 0.f;
#pragma endregion
};
